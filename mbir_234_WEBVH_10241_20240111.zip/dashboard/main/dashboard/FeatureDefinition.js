/******************************************************************************
 *	Copyright (c) 2004 Actuate Corporation and others.
 *	All rights reserved. This program and the accompanying materials 
 *	are made available under the terms of the Eclipse Public License v1.0
 *	which accompanies this distribution, and is available at
 *		http://www.eclipse.org/legal/epl-v10.html
 *	
 *	@fileoverview This file defines class actuate.iv.constant
 *	@author Actuate Corporation - IV Team
 *	@version 10.0
 *****************************************************************************/
actuate.util.Package.define( "actuate.dashboard" ); 

/**
 * Constant class serves as resource definition class for IV lazy loading use
 * @class This class serves as the resource definition class for IV lazy loading use.
 * @name actuate.iv.FeatureDefinition
 */

actuate.resource.module.feature.define("actuate.dashboard",
{
	
	_localizedStringServlet : "dashboardresource",
	
	/**
	 * Javascript resource definition which can be used by different features.
	 */
	javaScriptAlias : 
{
"GadgetExplorer" : "/feature8357049447522707124.js",
"FolderExplorer" : "/feature7558521783954669758.js",
"NewGadgetBuilderDialog" : "/feature14514322360595947360.js",
"NewSelectorBuilderDialog" : "/feature162480699847968972.js",
"NewReportLibraryBuilderDialog" : "/feature9498291227907897755.js",
"NewDataManagerDialog" : "/feature5899658989209919654.js"
	}, 
	
	/**
	 * Feature defintions for on demand loading use
	 */
	AVAILABLE_FEATURES : 
	{		
		GADGET_EXPLORER :
		{		 
			/**
			 * JS file list to be loaded
			 * @type {Array}
			 */
			_javaScript : [ 
					"GadgetExplorer" 
					],
			_localizedString : ["gadgetExplorer"]
		},
		
		FOLDER_EXPLORER:
		{
			/**
			 * JS file list to be loaded
			 * @type {Array}
			 */
			_javaScript : [ 
					"FolderExplorer" 
					],
			_localizedString : ["folderExplorer"]
		},
		
		BUILDER_DIALOG:
		{
			/**
			 * JS file list to be loaded
			 * @type {Array}
			 */
			_javaScript : [ 
					"NewGadgetBuilderDialog",
					"NewSelectorBuilderDialog",
					"NewReportLibraryBuilderDialog",
					"NewDataManagerDialog"
					]
		}
	}
});
