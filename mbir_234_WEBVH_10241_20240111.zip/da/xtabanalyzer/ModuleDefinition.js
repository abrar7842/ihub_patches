// This file is build time generated. Please don't modify. 
actuate.resource.module.define("actuate.xtabanalyzer",
{
_jsPath :  "da/xtabanalyzer",
_jsFiles : new Array( "xtabanalyzer.js" ),
	_publicClasses:
	{
		"actuate.XTabAnalyzer":"actuate.xtabanalyzer.impl.XTabAnalyzer",
		"actuate.xtabanalyzer.Exception": "actuate.xtabanalyzer.impl.Exception",
		"actuate.xtabanalyzer.OptionKeys": "actuate.xtabanalyzer.impl.OptionKeys",
		"actuate.xtabanalyzer.EventConstants": "actuate.xtabanalyzer.impl.EventConstants",		
		"actuate.xtabanalyzer.UIOptions": "actuate.xtabanalyzer.impl.UIOptions",
		"actuate.xtabanalyzer.PageContent": "actuate.xtabanalyzer.impl.PageContent",
		"actuate.xtabanalyzer.Crosstab": "actuate.xtabanalyzer.impl.Crosstab",
		"actuate.xtabanalyzer.Dimension": "actuate.xtabanalyzer.impl.Dimension",
		"actuate.xtabanalyzer.Measure": "actuate.xtabanalyzer.impl.Measure",
		"actuate.xtabanalyzer.Level": "actuate.xtabanalyzer.impl.Level",
		"actuate.xtabanalyzer.LevelAttribute": "actuate.xtabanalyzer.impl.LevelAttribute",
		"actuate.xtabanalyzer.Sorter": "actuate.xtabanalyzer.impl.Sorter",
		"actuate.xtabanalyzer.MemberValue": "actuate.xtabanalyzer.impl.MemberValue",
		"actuate.xtabanalyzer.Filter": "actuate.xtabanalyzer.impl.Filter",
		"actuate.xtabanalyzer.SubTotal": "actuate.xtabanalyzer.impl.SubTotal",
		"actuate.xtabanalyzer.GrandTotal": "actuate.xtabanalyzer.impl.GrandTotal",
		"actuate.xtabanalyzer.Total": "actuate.xtabanalyzer.impl.Total",	
		"actuate.xtabanalyzer.Driller": "actuate.xtabanalyzer.impl.Driller",
		"actuate.xtabanalyzer.Options": "actuate.xtabanalyzer.impl.Options",
		"actuate.xtabanalyzer.ParameterValue": "actuate.xtabanalyzer.impl.ParameterValue",
		"actuate.xtabanalyzer.Comparison": "actuate.xtabanalyzer.impl.Comparison",
		"actuate.xtabanalyzer.ComparisonCondition": "actuate.xtabanalyzer.impl.ComparisonCondition",
		"actuate.xtabanalyzer.ComparisonValue": "actuate.xtabanalyzer.impl.ComparisonValue",
		"noClass":null 
	},	
_noComma : null
});
