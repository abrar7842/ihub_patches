// This file is build time generated. Please don't modify. 
actuate.resource.module.define("actuate.html5charts",
{
_jsPath :  "iv/html5charts",
_jsFiles : new Array( "html5charts.js" ),
_noComma : null
});
