/******************************************************************************
 *	Copyright (c) 2004 Actuate Corporation and others.
 *	All rights reserved. This program and the accompanying materials 
 *	are made available under the terms of the Eclipse Public License v1.0
 *	which accompanies this distribution, and is available at
 *		http://www.eclipse.org/legal/epl-v10.html
 *	
 *	@fileoverview This file defines class actuate.iv.constant
 *	@author Actuate Corporation - IV Team
 *	@version 10.0
 *****************************************************************************/
actuate.util.Package.define( "actuate.dialog" ); 

/**
 * Constant class serves as resource definition class for IV lazy loading use
 * @class This class serves as the resource definition class for IV lazy loading use.
 * @name actuate.iv.FeatureDefinition
 */

actuate.resource.module.feature.define( "actuate.html5charts",
{
	/**
	 * JavaScript resource alias definition which can be used by difference features.
	 */
	javaScriptAlias : 
{

//WORLD_CONTINENTS
"alias_js_world"                             : "/feature3221173218296027120.js",
"alias_js_world8"                            : "/feature6278643065894446504.js",
"alias_js_world8withantarctica"              : "/feature7883590083278948763.js",
"alias_js_worldwithantarctica"               : "/feature854092064834611645.js",
"alias_js_worldwithcountries"                : "/feature3061053022405546253.js",
"alias_js_europe"                            : "/feature2401694251136062575.js",
"alias_js_northamerica"                      : "/feature3214067790337082002.js",
"alias_js_centralamerica"                    : "/feature4578936482320791609.js",
"alias_js_southamerica"                      : "/feature5430374947830776435.js",
"alias_js_asia"							     : "/feature8596158750423794990.js",
"alias_js_africa"						     : "/feature488472448540543994.js",
"alias_js_middleeast"                        : "/feature1668057685808562622.js",
"alias_js_oceania"                           : "/feature6016273820788684143.js",
"alias_js_asia3"						     : "/feature2030395744490752241.js",
"alias_js_northamericawocentral"             : "/feature6238801613166361667.js",

//USA_STATES :
"alias_js_alabama"			  :  "/feature5382954366570053026.js",
"alias_js_alaska"			  :  "/feature3432766959517048481.js",
"alias_js_arizona"            :  "/feature7051314600153960186.js",
"alias_js_arkansas"           :  "/feature3152362504558737088.js",
"alias_js_california"         :  "/feature8379811271339255148.js",
"alias_js_colorado"           :  "/feature417190265458381322.js",
"alias_js_connecticut"        :  "/feature5960316228128109320.js",
"alias_js_delaware"           :  "/feature3841756511569432451.js",
"alias_js_districtofcolumbia" :  "/feature8411666369820558405.js",
"alias_js_florida"            :  "/feature5071709944941678443.js",
"alias_js_georgia"            :  "/feature6400080070572475212.js",
"alias_js_hawaii"             :  "/feature6568172789591644669.js",
"alias_js_idaho"              :  "/feature2779187274815467854.js",
"alias_js_illinois"           :  "/feature9099993704709385357.js",
"alias_js_indiana"            :  "/feature740791468705076360.js",
"alias_js_iowa"               :  "/feature9121692953371147798.js",
"alias_js_kansas"             :  "/feature6497797770020276548.js",
"alias_js_kentucky"           :  "/feature5500417376771531243.js",
"alias_js_louisiana"          :  "/feature399776098437480857.js",
"alias_js_maine"              :  "/feature7953724031788499738.js",
"alias_js_maryland"           :  "/feature6956647800704551589.js",
"alias_js_massachusetts"      :  "/feature4093872955917329190.js",
"alias_js_michigan"           :  "/feature1466395379300766882.js",
"alias_js_minnesota"          :  "/feature5624937646887620318.js",
"alias_js_mississippi"        :  "/feature7487788116272965626.js",
"alias_js_missouri"           :  "/feature860261385060975755.js",
"alias_js_montana"            :  "/feature6511233690445580574.js",
"alias_js_nebraska"           :  "/feature4741293683974294885.js",
"alias_js_nevada"             :  "/feature4821517070700718775.js",
"alias_js_newhampshire"       :  "/feature3442250122238165140.js",
"alias_js_newjersey"          :  "/feature2188177244151599028.js",
"alias_js_newmexico"          :  "/feature667873848208391327.js",
"alias_js_newyork"            :  "/feature4257758444474282943.js",
"alias_js_northcarolina"      :  "/feature2978406856317951719.js",
"alias_js_northdakota"        :  "/feature2099013430780672649.js",
"alias_js_ohio"               :  "/feature5038913890010629928.js",
"alias_js_oklahoma"           :  "/feature7112749374673081101.js",
"alias_js_oregon"             :  "/feature1173074349044245390.js",
"alias_js_pennsylvania"       :  "/feature3764021214202752494.js",
"alias_js_rhodeisland"        :  "/feature8130975595018052613.js",
"alias_js_southcarolina"      :  "/feature1025618704323079147.js",
"alias_js_southdakota"        :  "/feature2485062663937518247.js",
"alias_js_tennessee"          :  "/feature7173666225730821964.js",
"alias_js_texas"              :  "/feature1223437915153495920.js",
"alias_js_usa"                :  "/feature5775296228991831770.js",
"alias_js_utah"               :  "/feature941010431322494834.js",
"alias_js_vermont"            :  "/feature1558868905425891230.js",
"alias_js_virginia"           :  "/feature7740238878385722252.js",
"alias_js_washington"         :  "/feature7283088806937527867.js",
"alias_js_westvirginia"       :  "/feature2444706767251110142.js",
"alias_js_wisconsin"          :  "/feature6093159242394719061.js",
"alias_js_wyoming"            :  "/feature649089388775124705.js",

//USA_REGIONS

"alias_js_usacentralregion"	    :  "/feature3246098624469039999.js",
"alias_js_usanortheastregion"   :  "/feature3762485745962513682.js",
"alias_js_usanorthwestregion"   :  "/feature5263032547674926514.js",
"alias_js_usaregion"            :  "/feature8726834894272468373.js",
"alias_js_usasoutheastregion"   :  "/feature2915046784896071683.js",
"alias_js_usasouthwestregion"   :  "/feature1971010330566091493.js",

//Europe

"alias_js_albania"                 :  "/feature8617140605821898902.js",
"alias_js_andorra"                 :  "/feature2382983397092656887.js",
"alias_js_austria"                 :  "/feature2643584468373673410.js",
"alias_js_belarus"                 :  "/feature6735201823016061660.js",
"alias_js_belgium"                 :  "/feature9158136612328475533.js",
"alias_js_bosniaherzegovina"       :  "/feature8427876325216211999.js",
"alias_js_bulgaria"                :  "/feature1482999042844359810.js",
"alias_js_croatia"                 :  "/feature1793378916700796948.js",
"alias_js_cyprus"                  :  "/feature1406061154831016893.js",
"alias_js_cyprus2"                 :  "/feature315134300760003284.js",
"alias_js_czechrepublic"           :  "/feature8559550179559315220.js",
"alias_js_denmark"                 :  "/feature9002904556736168642.js",
"alias_js_denmarkregion"           :  "/feature5307025755884467611.js",
"alias_js_england"                 :  "/feature599028781227638438.js",
"alias_js_estonia"                 :  "/feature6726929232502856857.js",
"alias_js_europe2"                 :  "/feature295147666903112078.js",
"alias_js_europewithcountries"     :  "/feature7694490282548977757.js",
"alias_js_finland"                 :  "/feature7162197874119524040.js",
"alias_js_france"                  :  "/feature6027999489628633765.js",
"alias_js_francedepartment"        :  "/feature6590682493949094555.js",
"alias_js_germany"                 :  "/feature3121844769587313338.js",
"alias_js_greece"                  :  "/feature5349657820292421430.js",
"alias_js_hungary"                 :  "/feature9199702991518731386.js",
"alias_js_hungaryregions"          :  "/feature6523826507464383337.js",
"alias_js_iceland"                 :  "/feature4748868650382750576.js",
"alias_js_ireland"                 :  "/feature5946541878008184078.js",
"alias_js_italy"                   :  "/feature9038883047613065431.js",
"alias_js_latvia"                  :  "/feature2848306603440209271.js",
"alias_js_liechtenstein"           :  "/feature400484864990889257.js",
"alias_js_lithuania"               :  "/feature4795232817467417842.js",
"alias_js_luxembourg"              :  "/feature8605306197828518646.js",
"alias_js_macedonia"               :  "/feature98938889949272622.js",
"alias_js_malta"                   :  "/feature1640819149907046302.js",
"alias_js_moldova"                 :  "/feature5962044772382246603.js",
"alias_js_monaco"                  :  "/feature296411595739592979.js",
"alias_js_montenegro"              :  "/feature2691035471994148051.js",
"alias_js_netherlands"             :  "/feature6177553597948484663.js",
"alias_js_norway"                  :  "/feature8114388666229145430.js",
"alias_js_norwayregion"            :  "/feature726943513970881269.js",
"alias_js_poland"                  :  "/feature7921026384661784613.js",
"alias_js_polandcounties"          :  "/feature3950861993345967388.js",
"alias_js_portugal"                :  "/feature633043555083579360.js",
"alias_js_romania"                 :  "/feature6580619380713368820.js",
"alias_js_sanmarino"               :  "/feature7905084246162801042.js",
"alias_js_scotland"                :  "/feature4059235737581726858.js",
"alias_js_serbia"                  :  "/feature3536632024757832870.js",
"alias_js_slovakia"                :  "/feature8203658910118985032.js",
"alias_js_slovenia"                :  "/feature6006542470023463006.js",
"alias_js_spain"                   :  "/feature4283345594196699803.js",
"alias_js_spainprovinces"          :  "/feature6626444395405356983.js",
"alias_js_sweden"                  :  "/feature8479050265367333898.js",
"alias_js_switzerland"             :  "/feature602251167251364186.js",
"alias_js_turkey"                  :  "/feature1311491916775018395.js",
"alias_js_uk"                      :  "/feature8593978792458261728.js",
"alias_js_ukraine"                 :  "/feature8766953334002330824.js",
"alias_js_vaticancity"             :  "/feature6331688176132612578.js",

//EUROPE_REGIONS
"alias_js_centraleuropeanregion"  :   "/feature5939145328174857850.js",
"alias_js_easteuropeanregion"     :   "/feature1623389047843914484.js",
"alias_js_europeregion"           :   "/feature7779538817889831241.js",
"alias_js_northeuropeanregion"    :   "/feature3507785169400877163.js",
"alias_js_southeuropeanregion"    :   "/feature6717710624309697571.js",
"alias_js_westeuropeanregion"     :   "/feature7685236307911206308.js",

//UNITED_KINGDOM
"alias_js_englandregion"      :   "/feature8062743270917417195.js",
"alias_js_northernireland"    :   "/feature2982990175341764726.js",
"alias_js_scotlandregion"     :   "/feature7317966216103768418.js",
"alias_js_uk7"                :   "/feature8128729623259448248.js",
"alias_js_wales"              :   "/feature3800082504397475554.js",

//NORTH_AMERICA
"alias_js_antigua"							:  "/feature7446467087772331267.js",
"alias_js_bahamas"                          :  "/feature1550093338357414624.js",
"alias_js_barbados"                         :  "/feature7733641057772986614.js",
"alias_js_canada"                           :  "/feature4644890873712596963.js",
"alias_js_caymanislands"                    :  "/feature2974871205999668963.js",
"alias_js_cuba"                             :  "/feature1677284973001785840.js",
"alias_js_dominica"                         :  "/feature861463395188428922.js",
"alias_js_dominicanrepublic"                :  "/feature6125238777343278819.js",
"alias_js_greenland"                        :  "/feature3742542730638931679.js",
"alias_js_grenada"                          :  "/feature173875112219732875.js",
"alias_js_haiti"                            :  "/feature3992927990444660444.js",
"alias_js_jamaica"                          :  "/feature4458579356641161702.js",
"alias_js_mexico"                           :  "/feature1163079342923871965.js",
"alias_js_puertorico"                       :  "/feature6897821993996655255.js",
"alias_js_saintkittsandnevis"               :  "/feature1616464672722677127.js",
"alias_js_saintlucia"                       :  "/feature8023971733440812769.js",
"alias_js_saintvincentandthegrenadines"     :  "/feature3522364484196459360.js",
"alias_js_trinidadandtobago"                :  "/feature6279523422452271532.js",

//SOUTH AMERICA
"alias_js_argentina"			:    "/feature6847132743689572903.js",
"alias_js_bolivia"              :    "/feature6352463273223121201.js",
"alias_js_brazil"               :    "/feature9013243014109973395.js",
"alias_js_brazilregion"         :    "/feature5795370863370291000.js",
"alias_js_chile"                :    "/feature8765267610328694315.js",
"alias_js_colombia"             :    "/feature5429450763130410916.js",
"alias_js_ecuador"              :    "/feature8614910824779348346.js",
"alias_js_falklandisland"       :    "/feature8391436767471577054.js",
"alias_js_frenchguiana"         :    "/feature7550465342714583785.js",
"alias_js_guyana"               :    "/feature2807090345287379622.js",
"alias_js_paraguay"             :    "/feature281993460267554982.js",
"alias_js_peru"                 :    "/feature5362714551981255430.js",
"alias_js_suriname"             :    "/feature4397317903202859374.js",
"alias_js_uruguay"              :    "/feature6843460057912196952.js",
"alias_js_venezuela"            :    "/feature3306362244048639039.js",

//CENTRAL_AMERICA
"alias_js_belize"						:  "/feature8676834021173590559.js",
"alias_js_centralamerica2"              :  "/feature7549704498288453742.js",
"alias_js_centralamericawithcaribbean"  :  "/feature7132324396600192728.js",
"alias_js_costarica"                    :  "/feature8358964869607675522.js",
"alias_js_elsalvador"                   :  "/feature175912667304148928.js",
"alias_js_guatemala"                    :  "/feature2532056987168455533.js",
"alias_js_honduras"                     :  "/feature8251894979804810061.js",
"alias_js_nicaragua"                    :  "/feature7402811261461367511.js",
"alias_js_panama"                       :  "/feature8352192949226356554.js",

//CANADA
"alias_js_alberta"					:  "/feature6972408150128278680.js",
"alias_js_britishcolumbia"          :  "/feature8989588989280180423.js",
"alias_js_manitoba"                 :  "/feature6622208331113993112.js",
"alias_js_newbrunswick"             :  "/feature5841745341620111718.js",
"alias_js_newfoundlandandlabrador"  :  "/feature5107763441056184309.js",
"alias_js_northwestterritories"     :  "/feature3422148525255164083.js",
"alias_js_novascotia"               :  "/feature1376639963823649419.js",
"alias_js_nunavut"                  :  "/feature689633947103061316.js",
"alias_js_ontario"                  :  "/feature4256063486480314194.js",
"alias_js_princeedwardisland"       :  "/feature1905269220918341897.js",
"alias_js_quebec"                   :  "/feature4827840424912175165.js",
"alias_js_saskatchewan"             :  "/feature8811144221608746895.js",
"alias_js_yukonterritory"           :  "/feature2687629474664500205.js",

//ASIA
"alias_js_armenia"        :    "/feature2995025952896195135.js",
"alias_js_asiageorgia"    :    "/feature7142801509780843605.js",
"alias_js_azerbaijan"     :    "/feature3369512644027685585.js",
"alias_js_bangladesh"     :    "/feature1587096173519433380.js",
"alias_js_bhutan"         :    "/feature1952578390514742832.js",
"alias_js_brunei"         :    "/feature985001177746728842.js",
"alias_js_burma"          :    "/feature6588388974536006242.js",
"alias_js_cambodia"       :    "/feature5887177751055388938.js",
"alias_js_china2"         :    "/feature6670003660174534391.js",
"alias_js_easttimor"      :    "/feature6216207690584892089.js",
"alias_js_hongkong"       :    "/feature4813608352439666194.js",
"alias_js_india"          :    "/feature4261117577669228565.js",
"alias_js_indonesia"      :    "/feature4344056504442873747.js",
"alias_js_japan"          :    "/feature8173364088798448462.js",
"alias_js_kazakhstan"     :    "/feature5858468611883429467.js",
"alias_js_laos"           :    "/feature8615489883694954360.js",
"alias_js_macau"          :    "/feature1639649969245384831.js",
"alias_js_malaysia"       :    "/feature6818878096703219351.js",
"alias_js_mongolia"       :    "/feature4668170319411576310.js",
"alias_js_nepal"          :    "/feature4187398072153192305.js",
"alias_js_northkorea"     :    "/feature5584179580869129773.js",
"alias_js_philippines"    :    "/feature162867817411530982.js",
"alias_js_russia"         :    "/feature7173413433903682975.js",
"alias_js_singapore"      :    "/feature9026768123795127548.js",
"alias_js_southkorea"     :    "/feature5362081260342436222.js",
"alias_js_srilanka"       :    "/feature3677063496150116774.js",
"alias_js_taiwan"         :    "/feature5499898744447259513.js",
"alias_js_thailand"       :    "/feature3072211866365097676.js",
"alias_js_tibet"          :    "/feature6425325990578130210.js",
"alias_js_vietnam"        :    "/feature4562769914212956500.js",

//MIDDLE EAST
"alias_js_afghanistan"		:   "/feature6654178382017145660.js",
"alias_js_bahrain"          :   "/feature4239976592677534083.js",
"alias_js_iran"             :   "/feature5692877769609723631.js",
"alias_js_iraq"             :   "/feature756205266450641856.js",
"alias_js_israel"           :   "/feature359030061474053548.js",
"alias_js_jordan"           :   "/feature2747264329515926917.js",
"alias_js_kuwait"           :   "/feature4350618003264347083.js",
"alias_js_kyrgyzstan"       :   "/feature7234821821032818896.js",
"alias_js_lebanon"          :   "/feature3092364917539134210.js",
"alias_js_oman"             :   "/feature769124592152829343.js",
"alias_js_pakistan"         :   "/feature6937605783361792084.js",
"alias_js_qatar"            :   "/feature8005717178124603178.js",
"alias_js_saudiarabia"      :   "/feature3969285409963206932.js",
"alias_js_syria"            :   "/feature1239130297206297122.js",
"alias_js_tajikistan"       :   "/feature5175179878978118582.js",
"alias_js_turkmenistan"     :   "/feature1786420128649077098.js",
"alias_js_uae"              :   "/feature2779073676728148334.js",
"alias_js_uzbekistan"       :   "/feature5325486354648201604.js",
"alias_js_yemen"            :   "/feature5221302651692348368.js",

//OCEANIA
"alias_js_australia"			:   "/feature2853937998092748268.js",
"alias_js_australia2"           :   "/feature4490818078083146752.js",
"alias_js_fiji"                 :   "/feature4866743890962158662.js",
"alias_js_kiribati"             :   "/feature3395442368081791888.js",
"alias_js_marshallisland"       :   "/feature26022963662904126.js",
"alias_js_micronesia"           :   "/feature8828631433922751641.js",
"alias_js_nauru"                :   "/feature827786609503865303.js",
"alias_js_newcaledonia"         :   "/feature7317398613095144468.js",
"alias_js_newzealand"           :   "/feature1244987612112226100.js",
"alias_js_palau"                :   "/feature8854693901134112551.js",
"alias_js_papuanewguinea"       :   "/feature5681418739430027071.js",
"alias_js_samoa"                :   "/feature6192546377401808964.js",
"alias_js_solomonisland"        :   "/feature128798130027909890.js",
"alias_js_tonga"                :   "/feature4892721485216846441.js",
"alias_js_tuvalu"               :   "/feature6865547974184344946.js",
"alias_js_vanuatu"              :   "/feature3181771737085724373.js",

//AFRICA

"alias_js_algeria"						:      "/feature1060639823148731225.js",
"alias_js_angola"						:      "/feature5371279135867165850.js",
"alias_js_benin"						:      "/feature4576684811904350718.js",
"alias_js_botswana"						:      "/feature7623250353325572657.js",
"alias_js_burkinafaso"					:      "/feature164992827355923094.js",
"alias_js_burundi"						:      "/feature3787262644972818215.js",
"alias_js_cameroon"						:      "/feature8665800164445724945.js",
"alias_js_capeverde"					:      "/feature3966014816972690744.js",
"alias_js_centralafricanrepublic"		:      "/feature2798201737580555537.js",
"alias_js_chad"                         :      "/feature1115179643573083428.js",
"alias_js_comoros"                      :      "/feature3351840516920812729.js",
"alias_js_congo"                        :      "/feature8790216215120113760.js",
"alias_js_cotedivoire"                  :      "/feature4016555637650502499.js",
"alias_js_democraticrepublicofcongo"    :      "/feature4444650241784569637.js",
"alias_js_djibouti"                     :      "/feature62307398462715197.js",
"alias_js_egypt"                        :      "/feature4701896539701178581.js",
"alias_js_equatorialguinea"             :      "/feature7115718808160827960.js",
"alias_js_eritrea"                      :      "/feature4764839402138067538.js",
"alias_js_ethiopia"                     :      "/feature5215524825275430109.js",
"alias_js_gabon"                        :      "/feature7310949203534910221.js",
"alias_js_gambia"                       :      "/feature1301359839495860754.js",
"alias_js_ghana"                        :      "/feature7504785748032770470.js",
"alias_js_guinea"                       :      "/feature3988649069169568761.js",
"alias_js_guineabissau"                 :      "/feature556852249353689218.js",
"alias_js_kenya"                        :      "/feature8330939145257791491.js",
"alias_js_lesotho"                      :      "/feature6093860284193159986.js",
"alias_js_liberia"                      :      "/feature7788789983018453717.js",
"alias_js_libya"                        :      "/feature1250676437268813159.js",
"alias_js_madagascar"                   :      "/feature7560374533960481628.js",
"alias_js_madagascarregions"            :      "/feature2162598435491611197.js",
"alias_js_malawi"                       :      "/feature8483452832840132448.js",
"alias_js_mali"                         :      "/feature8405793524593108289.js",
"alias_js_mauritania"                   :      "/feature7733524937326903035.js",
"alias_js_mauritius"                    :      "/feature1022341149499765878.js",
"alias_js_morocco"                      :      "/feature5765562464803493427.js",
"alias_js_mozambique"                   :      "/feature3948308050117522176.js",
"alias_js_namibia"                      :      "/feature6238911914033857273.js",
"alias_js_niger"                        :      "/feature5939279431722110893.js",
"alias_js_nigeria"                      :      "/feature1465511438889494079.js",
"alias_js_rwanda"                       :      "/feature8614788338954464961.js",
"alias_js_saotomeandprincipe"           :      "/feature5218269574259791341.js",
"alias_js_senegal"                      :      "/feature5600275928305161346.js",
"alias_js_seychelles"                   :      "/feature547347740517148019.js",
"alias_js_sierraleone"                  :      "/feature1554983328434299182.js",
"alias_js_somalia"                      :      "/feature837798416883699124.js",
"alias_js_southafrica"                  :      "/feature8715042576645093429.js",
"alias_js_sudan"                        :      "/feature3552657964174263983.js",
"alias_js_swaziland"                    :      "/feature8227083257647800388.js",
"alias_js_tanzania"                     :      "/feature2569317264759903283.js",
"alias_js_togo"                         :      "/feature4783315452579656552.js",
"alias_js_tunisia"                      :      "/feature5819328859605122197.js",
"alias_js_uganda"                       :      "/feature2845764025406189175.js",
"alias_js_westernsahara"                :      "/feature1151583048552849128.js",
"alias_js_zambia"                       :      "/feature6892717921595943327.js",
"alias_js_zimbabwe"                     :      "/feature5844986251598193495.js"
	}, 
	
	/**
	 * Feature defintions for on demand loading use
	 */
	AVAILABLE_FEATURES : 
	{
		/**
		 * Feature definition for WORLD_CONTINENTS .
		 */	
		WORLD :   
		{
			_javaScript   :  ["alias_js_world"]
		},
		
		WORLD8 :  
		{
			_javaScript	   :["alias_js_world8"]
		},
		
		WORLD8WITHANTARCTICA : 
		{
			_javaScript	   :["alias_js_world8withantarctica"]
		},
		WORLDWITHANTARCTICA :  
		{
			_javaScript	   :["alias_js_worldwithantarctica"]
		},
		WORLDWITHCOUNTRIES :
		{
			_javaScript	   :["alias_js_worldwithcountries"]
		},
		EUROPE :  
		{
			_javaScript	   :["alias_js_europe"]
		},
		
		NORTHAMERICA : 
		{
			_javaScript	   :["alias_js_northamerica"]
		},
		
		CENTRALAMERICA : 
		{
			_javaScript	   :["alias_js_centralamerica"]
		},
		SOUTHAMERICA : 
		{
			_javaScript	   :["alias_js_southamerica"
			           	    ]
		},
		ASIA :			
		{
			_javaScript	   :["alias_js_asia"]
		},
		AFRICA :
		{
			_javaScript	   :["alias_js_africa"]
		},
		
		MIDDLEEAST :     
		{
			_javaScript	   :["alias_js_middleeast"]
		},
		OCEANIA :
		{
			_javaScript	   :["alias_js_oceania"]
		},
		ASIA3 :	
		{
			_javaScript	   :["alias_js_asia3"]
		},
		NORTHAMERICAWOCENTRAL :  
		{
			_javaScript	   :["alias_js_northamericawocentral"]
		},
		
		/**
		 * Feature definition for USA_STATES .
		 */	
		ALABAMA :		
		{
			_javaScript	   :["alias_js_alabama"]
		},
		ALASKA :	
		{
			_javaScript	   :["alias_js_alaska"]
		},
		ARIZONA :   
		{
			_javaScript	   :["alias_js_arizona"]
		},
		ARKANSAS :  
		{
			_javaScript	   :["alias_js_arkansas"]
		},
		CALIFORNIA :
		{
			_javaScript	   :["alias_js_california"]
		},
		COLORADO : 
		{
			_javaScript	   :["alias_js_colorado"]
		},
		CONNECTICUT :     
		{
			_javaScript	   :["alias_js_connecticut"]
		},
		DELAWARE :  
		{
			_javaScript	   :["alias_js_delaware"]
		},
		DISTRICTOFCOLUMBIA :
		{
			_javaScript	   :["alias_js_districtofcolumbia"]
		},
		FLORIDA :
		{
			_javaScript	   :["alias_js_florida"]
		},
		GEORGIA :
		{
			_javaScript	   :["alias_js_georgia"]
		},
		HAWAII :
		{
			_javaScript	   :["alias_js_hawaii"]
		},
		IDAHO :
		{
			_javaScript	   :["alias_js_idaho"]
		},
		ILLINOIS :
		{
			_javaScript	   :["alias_js_illinois"]
		},
		INDIANA :
		{
			_javaScript	   :["alias_js_indiana"]
		},
		IOWA :
		{
			_javaScript	   :["alias_js_iowa"]
		},
		KANSAS :
		{
			_javaScript	   :["alias_js_kansas"]
		},
			
		KENTUCKY :
		{
			_javaScript	   :["alias_js_kentucky"]
		},
		LOUISIANA :
		{
			_javaScript	   :["alias_js_louisiana"]
		},
		MAINE :
		{
			_javaScript	   :["alias_js_maine"]
		},
		MARYLAND :
		{
			_javaScript	   :["alias_js_maryland"]
		},
		MASSACHUSETTS :
		{
			_javaScript	   :["alias_js_massachusetts"]
		},
		MICHIGAN :
		{
			_javaScript	   :["alias_js_michigan"]
		},
		MINNESOTA :
		{
			_javaScript	   :["alias_js_minnesota"]
		},
		MISSISSIPPI :
		{
			_javaScript	   :["alias_js_mississippi"]
		},
		MISSOURI :
		{
			_javaScript	   :["alias_js_missouri"]
		},
		MONTANA :
		{
			_javaScript	   :["alias_js_montana"]
		},
		NEBRASKA :
		{
			_javaScript	   :["alias_js_nebraska"]
		},
		NEVADA : 
		{
			_javaScript	   :["alias_js_nevada"]
		},
		NEWHAMPSHIRE :
		{
			_javaScript	   :["alias_js_newhampshire"]
		},
		NEWJERSEY :
		{
			_javaScript	   :["alias_js_newjersey"]
		},
		NEWMEXICO :
		{
			_javaScript	   :["alias_js_newmexico"]
		},
		NEWYORK : 
		{
			_javaScript	   :["alias_js_newyork"]
		},
		NORTHCAROLINA :
		{
			_javaScript	   :["alias_js_northcarolina"]
		},
		NORTHDAKOTA :
		{
			_javaScript	   :["alias_js_northdakota"]
		},
		OHIO :
		{
			_javaScript	   :["alias_js_ohio"]
		},
		OKLAHOMA :
		{
			_javaScript	   :["alias_js_oklahoma"]
		},
		OREGON :
		{
			_javaScript	   :["alias_js_oregon"]
		},
		PENNSYLVANIA :
		{
			_javaScript	   :["alias_js_pennsylvania"]
		},
		RHODEISLAND :
		{
			_javaScript	   :["alias_js_rhodeisland"]
		},
		SOUTHCAROLINA :
		{
			_javaScript	   :["alias_js_southcarolina"]
		},
		SOUTHDAKOTA : 
		{
			_javaScript	   :["alias_js_southdakota"]
		},
		TENNESSEE :
		{
			_javaScript	   :["alias_js_tennessee"]
		},
		TEXAS :
		{
			_javaScript	   :["alias_js_texas"]
		},
		USA : 
		{
			_javaScript	   :["alias_js_usa"]
		},
		UTAH :
		{
			_javaScript	   :["alias_js_utah"]
		},
			
		VERMONT :   
		{
			_javaScript	   :["alias_js_vermont"]
		},
		VIRGINIA :
		{
			_javaScript	   :["alias_js_virginia"]
		},
		WASHINGTON :
		{
			_javaScript	   :["alias_js_washington"]
		},
		WESTVIRGINIA :
		{
			_javaScript	   :["alias_js_westvirginia"]
		},
		WISCONSIN :
		{
			_javaScript	   :["alias_js_wisconsin"]
		},
		WYOMING :
		{
			_javaScript	   :["alias_js_wyoming"]
		},
		
		/**
		 * Feature definition for USA Regions .
		 */	
		USACENTRALREGION :
		{	
			_javaScript	   :["alias_js_usacentralregion"]
		},
		USANORTHEASTREGION :
		{
			_javaScript	   :["alias_js_usanortheastregion"]
		},
		USANORTHWESTREGION :
		{
			_javaScript	   :["alias_js_usanorthwestregion"]
		},
		USAREGION :
		{
			_javaScript	   :["alias_js_usaregion"]
		},
		USASOUTHEASTREGION :  
		{
			_javaScript	   :["alias_js_usasoutheastregion"]
		},
		USASOUTHWESTREGION :        
		{
			_javaScript	   :["alias_js_usasouthwestregion"]
		},
		

		/**
		 * Feature definition for Europe .
		 */	
		ALBANIA :
		{
			_javaScript	   :["alias_js_albania"]
		},
		ANDORRA :
		{
			_javaScript	   :["alias_js_andorra"]
		},
			
		AUSTRIA :  
		{
			_javaScript	   :["alias_js_austria"]
		},
		BELARUS : 
		{
			_javaScript	   :["alias_js_belarus"]
		},
		BELGIUM :
		{
			_javaScript	   :["alias_js_belgium"]
		},
		BOSNIAHERZEGOVINA :
		{
			_javaScript	   :["alias_js_bosniaherzegovina"]
		},
		BULGARIA :    
		{
			_javaScript	   :["alias_js_bulgaria"]
		},
		CROATIA :
		{
			_javaScript	   :["alias_js_croatia"]
		},
		CYPRUS :
		{
			_javaScript	   :["alias_js_cyprus"]
		},
		CYPRUS2 : 
		{
			_javaScript	   :["alias_js_cyprus2"]
		},
		CZECHREPUBLIC :  
		{
			_javaScript	   :["alias_js_czechrepublic"]
		},
		DENMARK :
		{
			_javaScript	   :["alias_js_denmark"]
		},
		DENMARKREGION :
		{
			_javaScript	   :["alias_js_denmarkregion"]
		},
		ENGLAND :
		{
			_javaScript	   :["alias_js_england"]
		},
		ESTONIA :
		{
			_javaScript	   :["alias_js_estonia"]
		},
		EUROPE2 :
		{
			_javaScript	   :["alias_js_europe2"]
		},
		EUROPEWITHCOUNTRIES :                       
		{
			_javaScript	   :["alias_js_europewithcountries"]
		},
			 
		FINLAND :  
		{
			_javaScript	   :["alias_js_finland"]
		},
		FRANCE :
		{
			_javaScript	   :["alias_js_france"]
		},
		FRANCEDEPARTMENT :  
		{
			_javaScript	   :["alias_js_francedepartment"]
		},
		GERMANY : 
		{
			_javaScript	   :["alias_js_germany"]
		},
		GREECE :
		{
			_javaScript	   :["alias_js_greece"]
		},
		HUNGARY :
		{
			_javaScript	   :["alias_js_hungary"]
		},
		HUNGARYREGIONS :
		{
			_javaScript	   :["alias_js_hungaryregions"]
		},
		ICELAND :
		{
			_javaScript	   :["alias_js_iceland"]
		},
		IRELAND :
		{
			_javaScript	   :["alias_js_ireland"]
		},
		ITALY :    
		{
			_javaScript	   :["alias_js_italy"]
		},
		LATVIA :   
		{
			_javaScript	   :["alias_js_latvia"]
		},
		LIECHTENSTEIN :
		{                             
			_javaScript	   :["alias_js_liechtenstein"]
		},
		
		LITHUANIA :
		{
			_javaScript	   :["alias_js_lithuania"]
		},
		LUXEMBOURG :
		{
			_javaScript	   :["alias_js_luxembourg"]
		},
		MACEDONIA :   
		{
			_javaScript	   :["alias_js_macedonia"]
		},
		MALTA :
		{
			_javaScript	   :["alias_js_malta"]
		},
		
		MOLDOVA : 
		{
			_javaScript	   :["alias_js_moldova"]
		},
		MONACO : 
		{
			_javaScript	   :["alias_js_monaco"]
		},
		MONTENEGRO :    
		{
			_javaScript	   :["alias_js_montenegro"]
		},
		NETHERLANDS :       
		{
			_javaScript	   :["alias_js_netherlands"]
		},
		NORWAY :    
		{
			_javaScript	   :["alias_js_norway"]
		},
		NORWAYREGION :    
		{
			_javaScript	   :["alias_js_norwayregion"]
		},
		POLAND :        
		{
			_javaScript	   :["alias_js_poland"]
		},
		POLANDCOUNTIES :     
		{
			_javaScript	   :["alias_js_polandcounties"]
		},
		PORTUGAL : 
		{
			_javaScript	   :["alias_js_portugal"]
		},
		ROMANIA :
		{
			_javaScript	   :["alias_js_romania"]
		},
		SANMARINO :  
		{
			_javaScript	   :["alias_js_sanmarino"]
		},
		SCOTLAND :    
		{
			_javaScript	   :["alias_js_scotland"]
		},
		SERBIA :     
		{
			_javaScript	   :["alias_js_serbia"]
		},
		SLOVAKIA :     
		{
			_javaScript	   :["alias_js_slovakia"]
		},
		SLOVENIA :     
		{
			_javaScript	   :["alias_js_slovenia"]
		},
		SPAIN :          
		{
			_javaScript	   :["alias_js_spain"]
		},
		SPAINPROVINCES :  
		{
			_javaScript	   :["alias_js_spainprovinces"]
		},
		SWEDEN : 
		{
			_javaScript	   :["alias_js_sweden"]
		},
		SWITZERLAND :  
		{
			_javaScript	   :["alias_js_switzerland"]
		},
		TURKEY :                
		{                   
			_javaScript	   :["alias_js_turkey"]     
		},
		UK :                 
		{                 
			_javaScript	   :["alias_js_uk"]    
		},
		UKRAINE :             
		{                    
			_javaScript	   :["alias_js_ukraine"]    
		},
		VATICANCITY :         
		{       
			_javaScript	   :["alias_js_vaticancity"]   
		},
		

		/**
		 * Feature definition for Europe Regions .
		 */	
		CENTRALEUROPEANREGION :
		{             
			_javaScript	   :["alias_js_centraleuropeanregion"]   
		},
		EASTEUROPEANREGION :   
		{                
			_javaScript	   :["alias_js_easteuropeanregion"]   
		},
		EUROPEREGION :        
		{                 
			_javaScript	   :["alias_js_europeregion"]  
		},
		NORTHEUROPEANREGION :  
		{                  
			_javaScript	   :["alias_js_northeuropeanregion"]     
		
		},
		SOUTHEUROPEANREGION :  
		{            
			_javaScript	   :["alias_js_southeuropeanregion"]    
		},
		WESTEUROPEANREGION :	
		{                 
			_javaScript	   :["alias_js_westeuropeanregion"]   
		},
		

		/**
		 * Feature definition for United Kingdom .
		 */	
		ENGLANDREGION :      
		{                
			_javaScript	   :["alias_js_englandregion"]    
		},
		NORTHERNIRELAND :     
		{           
			_javaScript	   :["alias_js_northernireland"]  
		},
		SCOTLANDREGION :      
		{                 
			_javaScript	   :["alias_js_scotlandregion"]   
		},
		UK7 :            
		{                
			_javaScript	   :["alias_js_uk7"]    
		},
		WALES :          
		{           
			_javaScript	   :["alias_js_wales"] 
		},
		

		/**
		 * Feature definition for North America.
		 */	
		ANTIGUA :			
		{			  
			_javaScript	   :["alias_js_antigua"]  
		},
		BAHAMAS :              
		{             
			_javaScript	   :["alias_js_bahamas"]    
		},
		BARBADOS :           
		{                
			_javaScript	   :["alias_js_barbados"]     
		},
		CANADA :              
		{                  
			_javaScript	   :["alias_js_canada"]     
		},
		CAYMANISLANDS :        
		{               
			_javaScript	   :["alias_js_caymanislands"]  
		},
		CUBA :                
		{             
			_javaScript	   :["alias_js_cuba"]   
		},
		DOMINICA :            
		{                   
			_javaScript	   :["alias_js_dominica"]  
		},
		DOMINICANREPUBLIC :    
		{   
			_javaScript	   :["alias_js_dominicanrepublic"]    
		},
		GREENLAND :     
		{       
			_javaScript	   :["alias_js_greenland"]    
		},
		GRENADA :    
		{           
			_javaScript	   :["alias_js_grenada"]     
		},
		HAITI :          
		{                 
			_javaScript	   :["alias_js_haiti"]  
		},
		JAMAICA :           
		{                
			_javaScript	   :["alias_js_jamaica"]     
		},
		MEXICO :             
		{                 
			
			_javaScript	   :["alias_js_mexico"]   
		},
		PUERTORICO :       
		{               
			_javaScript	   :["alias_js_puertorico"]  
		},
		SAINTKITTSANDNEVIS :  
		{                  
			_javaScript	   :["alias_js_saintkittsandnevis"]   
		},
		SAINTLUCIA :        
		{                 
			_javaScript	   :["alias_js_saintlucia"] 
		},
		SAINTVINCENTANDTHEGRENADINES : 
		{          
			_javaScript	   :["alias_js_saintvincentandthegrenadines"]    
		},
		TRINIDADANDTOBAGO :   
		{                
			_javaScript	   :["alias_js_trinidadandtobago"]     
		},
		

		/**
		 * Feature definition for South America.
		 */	
		ARGENTINA :			
		{                
			_javaScript	   :["alias_js_argentina"]     
		},
		BOLIVIA :             
		{                
			
			_javaScript	   :["alias_js_bolivia"]    
		},
		BRAZIL :          
		{        
			_javaScript	   :["alias_js_brazil"]   
		},
		BRAZILREGION :        
		{            
			_javaScript	   :["alias_js_brazilregion"]      
		},
		CHILE :              
		{        
			_javaScript	   :["alias_js_chile"]         
	    },
		COLOMBIA :           
		{               
			_javaScript	   :["alias_js_colombia"]         
		},
		ECUADOR :              
		{               
			_javaScript	   :["alias_js_ecuador"]         
		},
		FALKLANDISLAND :       
		{                 
			_javaScript	   :["alias_js_falklandisland"]        
		},
		FRENCHGUIANA :      
		{                    
			_javaScript	   :["alias_js_frenchguiana"]         
		},
		GUYANA :            
		{                
			_javaScript	   :["alias_js_guyana"]         
		},
		PARAGUAY :         
		{             
			_javaScript	   :["alias_js_paraguay"]         
		},
		PERU :         
		{             
			_javaScript	   :["alias_js_peru"]        
		},
		SURINAME :       
		{               
			_javaScript	   :["alias_js_suriname"]        
		},
		URUGUAY :  
		{             
			_javaScript	   :["alias_js_uruguay"]        
		},
		VENEZUELA :   
		{            
			_javaScript	   :["alias_js_venezuela"]        
		},
		

		/**
		 * Feature definition for Central America.
		 */	
		BELIZE :		
		{          
			_javaScript	   :["alias_js_belize"]        
		},
		CENTRALAMERICA2 :     
		{              
			_javaScript	   :["alias_js_centralamerica2"]        
		},
		CENTRALAMERICAWITHCARIBBEAN : 
		{          
			_javaScript	   :["alias_js_centralamericawithcaribbean"]    
		},
		COSTARICA :          
		{            
			_javaScript	   :["alias_js_costarica"]    
		},
		ELSALVADOR :   
		{                     
			_javaScript	   :["alias_js_elsalvador"]        
        },
		GUATEMALA :    
		{              
			_javaScript	   :["alias_js_guatemala"]        
	    },
		HONDURAS :      
		{               
			_javaScript	   :["alias_js_honduras"]        
		},
		NICARAGUA :     
		{            
			_javaScript	   :["alias_js_nicaragua"]        
		},
		PANAMA :       
		{              
			_javaScript	   :["alias_js_panama"]         
		},
		

		/**
		 * Feature definition for Canada .
		 */	
		ALBERTA :		
		{           
			_javaScript	   :["alias_js_alberta"]         
		},
		BRITISHCOLUMBIA :  
		{            
			_javaScript	   :["alias_js_britishcolumbia"]         
		},
		MANITOBA :     
		{            
			_javaScript	   :["alias_js_manitoba"]        
		},
		NEWBRUNSWICK :    
		{              
			_javaScript	   :["alias_js_newbrunswick"]        
		},
		NEWFOUNDLANDANDLABRADOR :   
		{             
			_javaScript	   :["alias_js_newfoundlandandlabrador"]        
		},
		NORTHWESTTERRITORIES : 
		{                 
			_javaScript	   :["alias_js_northwestterritories"]         
		},
		NOVASCOTIA :        
		{              
			_javaScript	   :["alias_js_novascotia"]         
		},
		NUNAVUT :         
		{                
			_javaScript	   :["alias_js_nunavut"]        
		},
		ONTARIO :          
		{               
			_javaScript	   :["alias_js_ontario"]         
		},
		PRINCEEDWARDISLAND :
		{               
			_javaScript	   :["alias_js_princeedwardisland"]        
		},
		QUEBEC :           
		{            
			_javaScript	   :["alias_js_quebec"]         
		},
		SASKATCHEWAN :       
		{               
			_javaScript	   :["alias_js_saskatchewan"]         
		},
		YUKONTERRITORY :   
		{            
			_javaScript	   :["alias_js_yukonterritory"]         
		},
		
		/**
		 * Feature definition for Asia .
		 */	
		ARMENIA :         
		{              
			_javaScript	   :["alias_js_armenia"]        
        },
		ASIAGEORGIA :       
		{            
			_javaScript	   :["alias_js_asiageorgia"]        
		},
		AZERBAIJAN :      
		{            
			_javaScript	   :["alias_js_azerbaijan"]        
		},
		BANGLADESH :    
		{         
			_javaScript	   :["alias_js_bangladesh"]        
		},
		BHUTAN :        
		{         
			_javaScript	   :["alias_js_bhutan"]         
		},
		BRUNEI :   
		{       
			_javaScript	   :["alias_js_brunei"]         
		},
		BURMA :        
		{         
			_javaScript	   :["alias_js_burma"]        
		},
		CAMBODIA :   
		{       
			_javaScript	   :["alias_js_cambodia"]         
		},
		CHINA2 :        
		{            
			_javaScript	   :["alias_js_china2"]         
		},
		EASTTIMOR :      
		{         
			_javaScript	   :["alias_js_easttimor"]         
		},
		HONGKONG :        
		{             
			_javaScript	   :["alias_js_hongkong"]         
		},
		INDIA :       
		{      
			_javaScript	   :["alias_js_india"]        
		},
		INDONESIA :     
		{        
			_javaScript	   :["alias_js_indonesia"]        
		},
		JAPAN :          
		{         
			_javaScript	   :["alias_js_japan"]        
		},
		KAZAKHSTAN :    
		{        
			_javaScript	   :["alias_js_kazakhstan"]        
		},
		LAOS :          
        {             
			_javaScript	   :["alias_js_laos"]         
		},
		MACAU :          
		{              
			_javaScript	   :["alias_js_macau"]        
		},
		MALAYSIA :      
		{           
			_javaScript	   :["alias_js_malaysia"]         
		},
		MONGOLIA :      
		{            
			_javaScript	   :["alias_js_mongolia"]         
		},
		NEPAL :         
		{        
			_javaScript	   :["alias_js_nepal"]        
		},
		NORTHKOREA : 
		{              
			_javaScript	   :["alias_js_northkorea"]      
		},
		PHILIPPINES :   
		{           
			_javaScript	   :["alias_js_philippines"]        
		},
		RUSSIA :       
		{              
			_javaScript	   :["alias_js_russia"]        
		},
		SINGAPORE :    
		{              
			_javaScript	   :["alias_js_singapore"]        
		},
		SOUTHKOREA :    
		{              
			_javaScript	   :["alias_js_southkorea"]        
		},
		SRILANKA :      
		{               
			_javaScript	   :["alias_js_srilanka"]       
			
		},
		TAIWAN :       
		{              
			_javaScript	   :["alias_js_taiwan"]        
		},
		THAILAND :      
		{               
			_javaScript	   :["alias_js_thailand"]        
		},
		TIBET :         
		{              
			_javaScript	   :["alias_js_tibet"]         
		},
		VIETNAM :       
		{               
			_javaScript	   :["alias_js_vietnam"]        
		},

		/**
		 * Feature definition for Middle East .
		 */	
		AFGHANISTAN :		
		{                 
			_javaScript	   :["alias_js_afghanistan"]         
		},
		BAHRAIN :   
		{           
			_javaScript	   :["alias_js_bahrain"]         
		},
		IRAN :      
		{             
			_javaScript	   :["alias_js_iran"]         
		},
		IRAQ :         
		{               
			_javaScript	   :["alias_js_iraq"]         
		},
		ISRAEL :      
		{                   
			_javaScript	   :["alias_js_israel"]         
		},
		JORDAN :     
		{                    
			_javaScript	   :["alias_js_jordan"]        
		},
		KUWAIT :      
		{           
			_javaScript	   :["alias_js_kuwait"]         
		},
		KYRGYZSTAN :    
		{               
			_javaScript	   :["alias_js_kyrgyzstan"]      
		},
		LEBANON :        
		{                
			_javaScript	   :["alias_js_lebanon"]       
		},
		OMAN :             
		{                 
			_javaScript	   :["alias_js_oman"]      
		},
		PAKISTAN :      
		{              
			_javaScript	   :["alias_js_pakistan"]     
		},
		QATAR :      
		{          
			_javaScript	   :["alias_js_qatar"]     
		},
		SAUDIARABIA :   
		{               
			_javaScript	   :["alias_js_saudiarabia"]   
		},
		SYRIA :          
		{            
			_javaScript	   :["alias_js_syria"]   
		},
		TAJIKISTAN :     
		{            
			_javaScript	   :["alias_js_tajikistan"]   
		},
		TURKMENISTAN :     
		{           
			_javaScript	   :["alias_js_turkmenistan"]    
		},
		UAE :        
		{            
			_javaScript	   :["alias_js_uae"]   
		},
		UZBEKISTAN :  
		{           
			_javaScript	   :["alias_js_uzbekistan"]     
		},
		YEMEN :    
		{           
			_javaScript	   :["alias_js_yemen"]    
		},
		

		/**
		 * Feature definition for Oceania .
		 */	
		AUSTRALIA :		
		{               
			_javaScript	   :["alias_js_australia"]     
		},
		AUSTRALIA2 :  
		{            
			_javaScript	   :["alias_js_australia2"]    
		},
		FIJI :      
		{              
			_javaScript	   :["alias_js_fiji"]    
		},
		KIRIBATI :             
		{             
			_javaScript	   :["alias_js_kiribati"]     
		},
		MARSHALLISLAND :      
		{                 
			_javaScript	   :["alias_js_marshallisland"]    
		},
		MICRONESIA :           
		{                
			_javaScript	   :["alias_js_micronesia"]        
		},
		NAURU :                
		{               
			_javaScript	   :["alias_js_nauru"]       
		},
		NEWCALEDONIA :        
		{                
			_javaScript	   :["alias_js_newcaledonia"]   
		},
		NEWZEALAND :          
		{              
			_javaScript	   :["alias_js_newzealand"]   
		},
		PALAU :               
		{            
			_javaScript	   :["alias_js_palau"]      
		},
		PAPUANEWGUINEA :      
		{           
			_javaScript	   :["alias_js_papuanewguinea"]       
		},
		SAMOA :               
		{           
			_javaScript	   :["alias_js_samoa"]    
		},
		SOLOMONISLAND :  
		{             
			_javaScript	   :["alias_js_solomonisland"]     
		},
		TONGA :            
		{              
			_javaScript	   :["alias_js_tonga"]     
		},
		TUVALU :      
		{             
			_javaScript	   :["alias_js_tuvalu"]       
		},
		VANUATU :              
		{           
			_javaScript	   :["alias_js_vanuatu"]   
		},
		

		/**
		 * Feature definition for Africa .
		 */	
		ALGERIA :			
		{		   
			_javaScript	   :["alias_js_algeria"]    
		},
		ANGOLA :			
		{		         
			_javaScript	   :["alias_js_angola"]     
		},
		BENIN :				
		{	          
			_javaScript	   :["alias_js_benin"]       
		},
		BOTSWANA :			
		{		     
			_javaScript	   :["alias_js_botswana"]    
		},
		BURKINAFASO :			
		{		  
			_javaScript	   :["alias_js_burkinafaso"]       
		},
		BURUNDI :			
		{		    
			_javaScript	   :["alias_js_burundi"]        
		},
		CAMEROON :				
		{	       
			_javaScript	   :["alias_js_cameroon"]      
		},
		CAPEVERDE :			
		{	       
			_javaScript	   :["alias_js_capeverde"]   
		},
		CENTRALAFRICANREPUBLIC :
		{	       
			_javaScript	   :["alias_js_centralafricanrepublic"]     
		},
		CHAD :      
		{              
			_javaScript	   :["alias_js_chad"]    
		},
		COMOROS :         
		{              
			_javaScript	   :["alias_js_comoros"]    
		},
		CONGO :               
		{         
			_javaScript	   :["alias_js_congo"]     
		},
		COTEDIVOIRE :         
		{             
			_javaScript	   :["alias_js_cotedivoire"]      
		},
		DEMOCRATICREPUBLICOFCONGO : 
		{
			_javaScript	   :["alias_js_democraticrepublicofcongo"]     
		},
		DJIBOUTI :          
		{            
			_javaScript	   :["alias_js_djibouti"]     
		},
		EGYPT :              
		{               
			_javaScript	   :["alias_js_egypt"]   
		},
		EQUATORIALGUINEA :     
		{          
			_javaScript	   :["alias_js_equatorialguinea"]      
		},
		ERITREA :     
		{             
			_javaScript	   :["alias_js_eritrea"]      
		},
		ETHIOPIA :        
		{         
			_javaScript	   :["alias_js_ethiopia"]    
		},
		GABON :              
		{         
			_javaScript	   :["alias_js_gabon"]    
		},
		GAMBIA :           
		{               
			_javaScript	   :["alias_js_gambia"]       
		},
		GHANA :            
		{             
			_javaScript	   :["alias_js_ghana"]      
		},
		GUINEA :              
		{          
			_javaScript	   :["alias_js_guinea"]     
		},
		GUINEABISSAU :     
		{           
			_javaScript	   :["alias_js_guineabissau"]   
		},
		KENYA :         
		{           
			_javaScript	   :["alias_js_kenya"]     
		},
		LESOTHO :         
		{          
			_javaScript	   :["alias_js_lesotho"]   
		},
		LIBERIA :            
		{            
			_javaScript	   :["alias_js_liberia"]     
		},
		LIBYA :      
		{          
			_javaScript	   :["alias_js_libya"]    
		},
		MADAGASCAR :        
		{          
			_javaScript	   :["alias_js_madagascar"]     
		},
		MADAGASCARREGIONS : 
		{                
			_javaScript	   :["alias_js_madagascarregions"]     
		},
		MALAWI :          
		{              
			_javaScript	   :["alias_js_malawi"]      
		},
		MALI :              
		{           
			_javaScript	   :["alias_js_mali"] 
		},
		MAURITANIA :         
		{           
			_javaScript	   :["alias_js_mauritania"]    
		},
		MAURITIUS :        
		{            
			_javaScript	   :["alias_js_mauritius"]      
		},
		MOROCCO :           
		{          
			_javaScript	   :["alias_js_morocco"]      
		},
		MOZAMBIQUE :         
		{               
			_javaScript	   :["alias_js_mozambique"]     
		},
		NAMIBIA :              
		{          
			_javaScript	   :["alias_js_namibia"]    
		},
		NIGER :           
		{          
			_javaScript	   :["alias_js_niger"]    
		},
		NIGERIA :             
		{                    
			_javaScript	   :["alias_js_nigeria"]   
		},
		RWANDA :    
		{          
			_javaScript	   :["alias_js_rwanda"]   
		},
		SAOTOMEANDPRINCIPE :  
		{           
			_javaScript	   :["alias_js_saotomeandprincipe"]      
		},
		SENEGAL :             
		{                   
			_javaScript	   :["alias_js_senegal"]      
		},
		SEYCHELLES :         
		{                
			_javaScript	   :["alias_js_seychelles"]      
		},
		SIERRALEONE :    
		{             
			_javaScript	   :["alias_js_sierraleone"]      
		},
		SOMALIA :             
		{         
			_javaScript	   :["alias_js_somalia"]    
		},
		SOUTHAFRICA :     
		{               
			_javaScript	   :["alias_js_southafrica"]   
		},
		SUDAN :          
		{                 
			_javaScript	   :["alias_js_sudan"]     
		},
		SWAZILAND :    
		{           
			_javaScript	   :["alias_js_swaziland"]      
		},
		TANZANIA :
		{        
			_javaScript	   :["alias_js_tanzania"]    
		},
		TOGO :     
		{               
			_javaScript	   :["alias_js_togo"]     
		},
		TUNISIA :       
		{            
			_javaScript	   :["alias_js_tunisia"]    
		},
		UGANDA :         
		{                 
			_javaScript	   :["alias_js_uganda"]       
		},
		WESTERNSAHARA :     
		{                   
			_javaScript	   :["alias_js_westernsahara"]    
		},
		ZAMBIA :      
		{         
			_javaScript	   :["alias_js_zambia"]     
		},
		ZIMBABWE :             
		{            
			_javaScript	   :["alias_js_zimbabwe"]      
		}
	}
});
