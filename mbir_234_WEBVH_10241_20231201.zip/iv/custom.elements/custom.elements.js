class MBIRDashboard extends HTMLElement {
    constructor() {
        super();		
    }
	
	connectedCallback(){
		this._initComponent( );
	}
	
	getConstants = ( )=>{
		
		return {
			ATTRIBUTE:{
				PATH :'path',
				YAML : 'yaml',
				YAML_PATH: 'yamlPath',
				USER_NAME : 'userName',
				REQUEST_OPTIONS : 'requestOptions',
				EXTENDED_CRENDENTIALS : 'extendedCredentials',
				URL : 'url',
				DASHBOARD_OPTIONS : 'dashboardOptions',
				PASSWORD : 'password',
				WIDTH : 'width',
				HEIGHT : 'height',
				AUTH_TOKEN : 'authToken',
				WRAPPER_ID : 'id'
			},
			
			JSAPI:{
				DASHBOARD : 'dashboard'
			}, 
			
			REQUEST_HEADERS:{
				AUTH_TOKEN : 'AuthToken',
				AUTHORIZATION: 'Authorization'
			}
		}
	}
	
	
	_initComponent = ( )=>{
		this.Constants = this.getConstants( );
		actuate.load(this.Constants.JSAPI.DASHBOARD);
		
		const baseURL = this.getURL( );
		const reqOps = this._getRequestOptions();
		
		const userName = this.getAttribute(this.Constants.ATTRIBUTE.USER_NAME);
		const password = this.getAttribute(this.Constants.ATTRIBUTE.PASSWORD);

		if( !reqOps.getRepositoryType( ) )
			reqOps.setRepositoryType(actuate.RequestOptions.REPOSITORY_ENCYCLOPEDIA);//default
		if (!reqOps.getVolumeProfile())
			reqOps.setVolumeProfile("enterprise");//default

		if(this._validateInput()) {
            if(!actuate.isInitialized()) {
                actuate.initialize(baseURL, reqOps, userName, password, this.initRunDashboard);
            } else {
                actuate.authenticate(baseURL, reqOps, userName, password, null, this.initRunDashboard);
            }
        }
	}
	
	_validateInput = () => {
        //validate mandatory inputs
        //url
        let valid = true;
        if(! this.getURL()) {
            console.error("url attribute must be provided");
            valid = false;
        }
        //auth
        const userName = this.getAttribute(this.Constants.ATTRIBUTE.USER_NAME);
        const authToken = this.getAttribute(this.Constants.ATTRIBUTE.AUTH_TOKEN);
        if(! userName && ! (authToken && authToken.length > 5)) {
            console.error("username/password or authToken attribute must be provided");
            valid = false;
        }
        //yaml input
        const yaml = this.getAttribute(this.Constants.ATTRIBUTE.YAML);
        const yamlPath = this.getAttribute(this.Constants.ATTRIBUTE.YAML_PATH);
        const dashboardPath = this.getAttribute(this.Constants.ATTRIBUTE.PATH);
        if(! (yaml && yaml.length) && ! yamlPath && ! dashboardPath) {
            console.error("one of these attributes must be provided - 'path', 'yamlPath', 'yaml'");
            valid = false;
        }
        //wraper id
        if(! this.getAttribute(this.Constants.ATTRIBUTE.WRAPPER_ID)) {
            console.error("element 'id' must be provided");
            valid = false;
        }

        return valid;
    }
	
	runDashboard = ( dashboard ) =>{
		const wrapperId = this.getAttribute(this.Constants.ATTRIBUTE.WRAPPER_ID);
		dashboard = dashboard || new actuate.Dashboard(wrapperId);
		this._setDashboardOptions( dashboard );
		dashboard.submit( );  
	}
	
	_setDashboardOptions = ( dashboard )=>{
		const name = this.getAttribute(this.Constants.ATTRIBUTE.PATH);
		const width = this.getAttribute(this.Constants.ATTRIBUTE.WIDTH);
		const height = this.getAttribute(this.Constants.ATTRIBUTE.HEIGHT);
		
		if( width )
			dashboard.setWidth( width );
		
		if( height )
			dashboard.setHeight( height );
		
		if( name )
			dashboard.setDashboardName( name );
		
		
		const strDashboardOptions = this.getAttribute(this.Constants.ATTRIBUTE.DASHBOARD_OPTIONS);
		
		let dashboardOptions;
		
		if( strDashboardOptions ){
				dashboardOptions = JSON.parse( strDashboardOptions );
		}
		
		if( dashboardOptions ){
			if( !dashboard.getDashboardName() && dashboardOptions.dashboardName )
				dashboard.setDashboardName( dashboardOptions.dashboardName );
			
			if( dashboardOptions.isDesigner == "true" )
				dashboard.setIsDesigner( true );
			
			if( dashboardOptions.activeTab )
				dashboard.setActiveTab( dashboardOptions.activeTab );
			
			if( dashboardOptions.container )
				dashboard.setContainer( dashboardOptions.container );
			
			if( dashboardOptions.height )
				dashboard.setHeight( dashboardOptions.height );
			
			if( dashboardOptions.width )
				dashboard.setWidth( dashboardOptions.width );
			
			if( dashboardOptions.isStandalone == "true")
				dashboard.setIsStandalone( true );
			
			if( dashboard.service )
				dashboard.setService( dashboardOptions.service );
			
			if( dashboard.size )
				dashboard.setSize( dashboardOptions.size.width, dashboardOptions.size.height );
			
			if( dashboard.template )
				dashboard.setTemplate( dashboardOptions.template );
			
		}		
		
	}
	
	_formatURL = ( url ) =>{
		if(url && url.endsWith('/')) {
			url = url.substr(0,url.length-1);
		}
		
		return url;
	}
	
	
	getURL = () =>{
		
		if( this.baseURL ){
			return this.baseURL;
		}
		
		let baseURL = "";
		
		if( this.getAttribute(this.Constants.ATTRIBUTE.URL) ){
			baseURL = this._formatURL(this.getAttribute(this.Constants.ATTRIBUTE.URL));
		}else{
			baseURL = this._formatURL( actuate.reqBaseURL );
		}
		
		return this.baseURL = baseURL;
	}
	
	_getRequestOptions = ()=>{
		const requestOptions = new actuate.RequestOptions( );
		
		const credentials = this.getAttribute(this.Constants.ATTRIBUTE.EXTENDED_CRENDENTIALS);
		const authToken = this.getAttribute(this.Constants.ATTRIBUTE.AUTH_TOKEN);
		
		if( credentials ){
			requestOptions.setCredentials( credentials );
		}else if( authToken ){
			requestOptions.setExternalToken( authToken );
		}
		
		const strReqOps = this.getAttribute(this.Constants.ATTRIBUTE.REQUEST_OPTIONS);
		
		if( strReqOps ){
				var  reqOps = JSON.parse( strReqOps );
		}
		
		if( reqOps ){
			if( reqOps.credentials )
				requestOptions.setCredentials( reqOps.credentials );
			else if( reqOps.RESTAuthToken )
				requestOptions.setRESTAuthToken( reqOps.RESTAuthToken );
			
			if( reqOps.repositoryType )
				requestOptions.setRepositoryType( reqOps.repositoryType );
			
			
			const customParams = reqOps.customParameters;
						
			if( customParams )
				requestOptions.setCustomParameters( customParams );
						
			if( reqOps.iServerUrl )
				requestOptions.setIServerUrl( reqOps.iServerUrl );
			
			if( reqOps.locale )
				requestOptions.setLocale( reqOps.locale );
			
			if( reqOps.volume )
				requestOptions.setVolume( reqOps.volume );

			if (reqOps.volumeProfile)
				requestOptions.setVolumeProfile(reqOps.volumeProfile);
			else
				requestOptions.setVolumeProfile("enterprise");
			
		}
		
		
		return requestOptions;
	}
	
	_runYamlGeneratedDashboard = ( dashboardName ) =>{
		const wrapperId = this.getAttribute(this.Constants.ATTRIBUTE.WRAPPER_ID);
		const dashboard = new actuate.Dashboard(wrapperId);
		dashboard.setDashboardName( dashboardName );
		
		this.runDashboard( dashboard );
	}
	
	initRunDashboard = () => {
        let yamlInput = this.getAttribute(this.Constants.ATTRIBUTE.YAML);
        const yamlPath = this.getAttribute(this.Constants.ATTRIBUTE.YAML_PATH);
        if (yamlInput) {
            this._createDashboard(yamlInput);
        } else if (yamlPath) {
            fetch(yamlPath)
                .then(response => response.text())
                .then(yaml => this._createDashboard(yaml))
        } else if (this.getAttribute(this.Constants.ATTRIBUTE.PATH)) {
            this.runDashboard();
        }
    }

	 _createDashboard = (yamlInput)=>{
		const ele = this;
		const userName = this.getAttribute(this.Constants.ATTRIBUTE.USER_NAME);
		const authToken = this.getAttribute( this.Constants.ATTRIBUTE.AUTH_TOKEN );
		let url = this.getURL( ) + "/declarativebi";
		if( userName ){
			url += "?userid="+userName;
		}
		const xhr = new XMLHttpRequest();
			xhr.open("POST", url, true);
			if( !userName && authToken ){
					xhr.setRequestHeader( this.Constants.REQUEST_HEADERS.AUTHORIZATION, "Bearer " + authToken);
			}
			xhr.send(yamlInput);
			let runYamlGeneratedDashboard = this._runYamlGeneratedDashboard;
			xhr.onload = function(){
				const textResponse = this.responseText;
				const json = JSON.parse(textResponse);
				const fileName = json.GraphicalMetrics.filename;
				
				runYamlGeneratedDashboard( fileName );
			}
	  }

	static get observedAttributes() {
		return ["yaml", "authToken", "authtoken"];
	}

	get authToken() {
		return this.hasAttribute("authToken");
	}

	set authToken(value) {
		return this.setAttribute("authToken", value);
	}

	get authtoken() {
		return this.hasAttribute("authtoken");
	}

	set authtoken(value) {
		return this.setAttribute("authtoken", value);
	}

	get yaml() {
		return this.hasAttribute("yaml");
	}

	set yaml(value) {
		return this.setAttribute("yaml", value);
	}

	attributeChangedCallback(name, oldValue, newValue) {
		if((name === "yaml" || name === "authToken" || name === "authtoken") && newValue) {
			this._initComponent();
		}
	}
}

customElements.define('mbir-dashboard', MBIRDashboard);
class MBIRReport extends HTMLElement {
    constructor() {
        super();
    }

    connectedCallback() {
        this._initComponent();
    }

    getConstants = () => {

        return {
            ATTRIBUTE: {
                PATH: 'path',
                YAML: 'yaml',
                YAML_PATH: 'yamlPath',
                USER_NAME: 'userName',
                REQUEST_OPTIONS: 'requestOptions',
                EXTENDED_CRENDENTIALS: 'extendedCredentials',
                URL: 'url',
                REPORT_PARAMS: 'reportParams',
                REPORT_OPTIONS: 'reportOptions',
                PASSWORD: 'password',
                WIDTH: 'width',
                HEIGHT: 'height',
                AUTH_TOKEN: 'authToken',
                WRAPPER_ID: 'id'
            },

            JSAPI: {
                REPORT: 'viewer',
                PARAMETER: 'parameter'
            },

            REQUEST_HEADERS: {
                AUTH_TOKEN: 'AuthToken',
                AUTHORIZATION: 'Authorization',
                TARGET_VOLUME: 'TargetVolume'
            }
        }
    }

    _getSupportedUIEvents = () => {
        const map = new Map();

        map.set("onchange", actuate.viewer.EventConstants.ON_CONTENT_CHANGED);
        map.set("onselected", actuate.viewer.EventConstants.ON_CONTENT_SELECTED);
        map.set("onsessiontimeout", actuate.viewer.EventConstants.ON_SESSION_TIMEOUT);
        map.set("onexception", actuate.viewer.EventConstants.ON_EXCEPTION);
        map.set("ondialogok", actuate.viewer.EventConstants.ON_DIALOG_OK);
        map.set("oncontentdragselection", actuate.viewer.EventConstants.ON_CONTENT_DRAG_SELECTION);
        map.set("oncontentdropselection", actuate.viewer.EventConstants.ON_CONTENT_DROP_SELECTION);
        map.set("onfilterbroadcast", actuate.viewer.EventConstants.ON_FILTER_BROADCAST);

        return map;
    }

    _initComponent = () => {
        this.Constants = this.getConstants();
        actuate.load(this.Constants.JSAPI.REPORT);
        actuate.load(this.Constants.JSAPI.PARAMETER);

        let valid = true;
        let errMsg = "";

        const baseURL = this.getURL();
        const reqOps = this._getRequestOptions();

        const userName = this._getSybilAttribute(this.Constants.ATTRIBUTE.USER_NAME);
        const password = this._getSybilAttribute(this.Constants.ATTRIBUTE.PASSWORD);
        const authToken = this._getSybilAttribute(this.Constants.ATTRIBUTE.AUTH_TOKEN);

        //check userName and authToken
        if(!userName) {
            if(!authToken) {
                valid = false;
            } else {
                if (authToken.length > 0 && authToken.length <= 5) {
                    errMsg = "invalid authToken attribute";
                    console.error(errMsg);
                    this._showErrorMessage(errMsg);
                    valid = false;
                }
            }
        }

        if (!reqOps.getRepositoryType())
            reqOps.setRepositoryType(actuate.RequestOptions.REPOSITORY_ENCYCLOPEDIA);//default
        if (!reqOps.getVolumeProfile())
            reqOps.setVolumeProfile("enterprise");//default

        if (valid) {
            errMsg = this._validateInput();
            if (errMsg === "") {
                if(!actuate.isInitialized()) {
                    actuate.initialize(baseURL, reqOps, userName, password, this.initRunReport);
                } else {
                    actuate.authenticate(baseURL, reqOps, userName, password, null, this.initRunReport);
                }
            } else {
                console.error(errMsg);
                this._showErrorMessage(errMsg);
            }
        }
    }

    _validateInput = () => {
        //validate mandatory inputs
        //url
        let errMsg = "";
        if(! this.getURL()) {
            errMsg = "url attribute must be provided";
        }

        //yaml input
        const yaml = this._getSybilAttribute(this.Constants.ATTRIBUTE.YAML);
        const yamlPath = this._getSybilAttribute(this.Constants.ATTRIBUTE.YAML_PATH);
        const reportPath = this._getSybilAttribute(this.Constants.ATTRIBUTE.PATH);
        if(! (yaml && yaml.length) && ! yamlPath && ! reportPath) {
            errMsg = "one of these attributes must be provided - 'path', 'yamlPath', 'yaml'";
        }
        //wrapper id
        if(! this._getSybilAttribute(this.Constants.ATTRIBUTE.WRAPPER_ID)) {
            errMsg = "element 'id' must be provided";
        }

        return errMsg;
    }

    runReport = (report) => {
        const wrapperId = this._getSybilAttribute(this.Constants.ATTRIBUTE.WRAPPER_ID);
        report = report || new actuate.Viewer(wrapperId);
        this._setReportOptions(report);

        this.initParamsTags();

        const paramObj = new actuate.Parameter("parampane_" + wrapperId);
        paramObj.registerEventHandler(actuate.parameter.EventConstants.ON_EXCEPTION, this.parameterErrorHandler);
        paramObj.setView(actuate.parameter.Constants.VIEW_MODERN);
        paramObj.setReportName(report.getReportName());
        paramObj.submit(() => {
            if (paramObj.getParameterValues() != null) {
                document.getElementById(
                    "runwithparams_" + wrapperId
                ).style.visibility = "visible";
            } else {
                //if no param run report directly
                report.submit(() => report.enableIV());
            }
        });
        document
            .getElementById("runwithparams_" + wrapperId)
            .addEventListener("click", () => this._runReportWithParameters(paramObj, report));
    }

    _setReportOptions = (report) => {
        const name = this._getSybilAttribute(this.Constants.ATTRIBUTE.PATH);
        const width = this._getSybilAttribute(this.Constants.ATTRIBUTE.WIDTH);
        const height = this._getSybilAttribute(this.Constants.ATTRIBUTE.HEIGHT);

        if (width)
            report.setWidth(width);

        if (height)
            report.setHeight(height);

        if (name)
            report.setReportName(name);


        const strReportOptions = this._getSybilAttribute(this.Constants.ATTRIBUTE.REPORT_OPTIONS);

        let reportOptions;

        if (strReportOptions) {
            reportOptions = JSON.parse(strReportOptions);
        }

        if (reportOptions) {
            if (!report.setReportName() && reportOptions.reportName)
                report.setReportName(reportOptions.reportName);

            if (reportOptions.isInteractive == "true")
                report.enableIV();

            if (reportOptions.height)
                report.setHeight(reportOptions.height);

            if (reportOptions.width)
                report.setWidth(reportOptions.width);

            if (report.service)
                report.setService(reportOptions.service);

            if (report.size)
                report.setSize(reportOptions.size.width, reportOptions.size.height);

        }

    }

    _formatURL = (url) => {
        if (url && url.endsWith('/')) {
            url = url.substr(0, url.length - 1);
        }

        return url;
    }


    getURL = () => {

        if (this.baseURL) {
            return this.baseURL;
        }

        let baseURL = "";

        if( this.getAttribute(this.Constants.ATTRIBUTE.URL) ){
            baseURL = this._formatURL(this.getAttribute(this.Constants.ATTRIBUTE.URL));
        }else{
            baseURL = this._formatURL( actuate.reqBaseURL );
        }

        return this.baseURL = baseURL;
    }

    _getRequestOptions = () => {
        const requestOptions = new actuate.RequestOptions();

        const credentials = this._getSybilAttribute(this.Constants.ATTRIBUTE.EXTENDED_CRENDENTIALS);
        const authToken = this._getSybilAttribute(this.Constants.ATTRIBUTE.AUTH_TOKEN);

        if (credentials) {
            requestOptions.setCredentials(credentials);
        } else if (authToken && authToken.length > 5) {
            requestOptions.setExternalToken(authToken);
        }

        const strReqOps = this._getSybilAttribute(this.Constants.ATTRIBUTE.REQUEST_OPTIONS);

        if (strReqOps) {
            var reqOps = JSON.parse(strReqOps);
        }

        if (reqOps) {
            if (reqOps.credentials)
                requestOptions.setCredentials(reqOps.credentials);
            else if (reqOps.RESTAuthToken)
                requestOptions.setRESTAuthToken(reqOps.RESTAuthToken);

            if (reqOps.repositoryType)
                requestOptions.setRepositoryType(reqOps.repositoryType);


            const customParams = reqOps.customParameters;

            if (customParams)
                requestOptions.setCustomParameters(customParams);

            if (reqOps.iServerUrl)
                requestOptions.setIServerUrl(reqOps.iServerUrl);

            if (reqOps.locale)
                requestOptions.setLocale(reqOps.locale);

            if (reqOps.volume)
                requestOptions.setVolume(reqOps.volume);

            if (reqOps.volumeProfile)
                requestOptions.setVolumeProfile(reqOps.volumeProfile);
            else 
                requestOptions.setVolumeProfile("enterprise");

        }


        return requestOptions;
    }

    _runYamlGeneratedReport = (yamlResponse) => {
        const reportName = yamlResponse.filename;
        const wrapperId = this._getSybilAttribute(this.Constants.ATTRIBUTE.WRAPPER_ID);
        const config = new actuate.viewer.UIConfig();
        config.setContentPanel(new actuate.viewer.BrowserPanel());
        const report = new actuate.Viewer(wrapperId, config);
        report.setReportName(reportName);

        if(yamlResponse.uioptions && yamlResponse.uioptions.events) {
            if(! yamlResponse.uioptions.shownavigation) {
                report.setUIOptions(this._getDefaultUIOptions());
            }
            this._setUIEvents(yamlResponse.uioptions.events, report);
        }
        this.runReport(report);
    }

    _showErrorMessage = (errMsg) => {
        var errorContentsDiv = document.createElement("div");
        errorContentsDiv.setAttribute("id", "validationError");
        errorContentsDiv.setAttribute(
          "style",
          "visibility: visible; margin: 10px 10px 0px; font-size: 14pt;"
        );
        const errorMsgPara = document.createElement("p");
        const errorMsgText = document.createTextNode("error: " + errMsg);
        errorMsgPara.appendChild(errorMsgText);
        errorContentsDiv.appendChild(errorMsgPara);

        const parent = document.getElementsByTagName("mbir-report")[0].parentNode;
        parent.appendChild(errorContentsDiv);
    }

    _showYamlValidationErrorMessages = (yamlResponse) => {
        var errorContentsDiv = document.createElement("div");
        errorContentsDiv.setAttribute("id", "mbirReportErrors");
        errorContentsDiv.setAttribute(
          "style",
          "visibility: visible; margin: 10px 10px 0px; font-size: 14pt;"
        );
        const errorCodePara = document.createElement("p");
        const errorCodeText = document.createTextNode("error code: " + yamlResponse["errorCode"]);
        errorCodePara.appendChild(errorCodeText);
        errorContentsDiv.appendChild(errorCodePara);

        const errorMessagePara = document.createElement("p");
        const errorMessageText = document.createTextNode("error message: " + yamlResponse["message"]);
        errorMessagePara.appendChild(errorMessageText);
        errorContentsDiv.appendChild(errorMessagePara);

        const errorDetailsPromptPara = document.createElement("p");
        const errorDetailsPrompText = document.createTextNode("Details:");
        errorDetailsPromptPara.appendChild(errorDetailsPrompText);
        errorContentsDiv.appendChild(errorDetailsPromptPara);

        const errorDetailsPara = document.createElement("p");
        const errorsArray = yamlResponse["errors"];
        for (var i=0; i<errorsArray.length; i++) {
	        var errorDetailPara = document.createElement("p");
            var errorDetailText = document.createTextNode(errorsArray[i]);
            errorDetailPara.appendChild(errorDetailText);
            errorDetailsPara.appendChild(errorDetailPara);
	    }
        errorContentsDiv.appendChild(errorDetailsPara);

        const parent = document.getElementById(this._getSybilAttribute(this.Constants.ATTRIBUTE.WRAPPER_ID)).parentNode;
        parent.appendChild(errorContentsDiv);
    }

    _getDefaultUIOptions = () => {
        const ui = new actuate.viewer.UIOptions( );
        ui.enableParameterPage( true );
        ui.enableLaunchViewer( false );
        ui.enableEditReport( false );
        ui.enableTOC( false );
        ui.enableSaveDesign( false );
        ui.enableSaveDocument( false );
        ui.enablePrint( false );
        ui.enableHideShowItems( false );
        ui.enableLinkToThisPage( false );
        ui.enableToolBar( false );
        ui.enableContentMargin( false );
        return ui;
    }

    _setUIEvents = (uievents, viewer) => {
        let self = this;
        this.supportedUIEvents = this._getSupportedUIEvents();
        uievents.forEach(function (uievent) {
            if (uievent.name && uievent.callback) {
                let jsapiEvent = self.supportedUIEvents.get(uievent.name);
                if(jsapiEvent) {
                    viewer.registerEventHandler(jsapiEvent, eval(uievent.callback));
                }
            }
        });
    }

    initRunReport = () => {
        let yamlInput = this._getSybilAttribute(this.Constants.ATTRIBUTE.YAML);
        const yamlPath = this._getSybilAttribute(this.Constants.ATTRIBUTE.YAML_PATH);
        if (yamlInput) {
            this._createReport(yamlInput);
        } else if (yamlPath) {
            fetch(yamlPath)
                .then(response => response.text())
                .then(yaml => this._createReport(yaml))
        } else if (this._getSybilAttribute(this.Constants.ATTRIBUTE.PATH)) {
            this.runReport();
        }
    }

    _createReport = (yamlInput) => {
        const ele = this;
        const userName = this._getSybilAttribute(this.Constants.ATTRIBUTE.USER_NAME);
        const authToken = this._getSybilAttribute(this.Constants.ATTRIBUTE.AUTH_TOKEN);
        const requestOptions = this._getSybilAttribute(
          this.Constants.ATTRIBUTE.REQUEST_OPTIONS);
        var targetVolume;
        if(requestOptions) {
          var objRequestOptions = JSON.parse(requestOptions);
          if(objRequestOptions.volume)
            targetVolume = objRequestOptions.volume;
        }
        let url = this.getURL() + "/declarativebi"
        if (userName) {
            url += "?userid=" + userName;
        }
        const xhr = new XMLHttpRequest();
        xhr.onload = function () {
            const textResponse = this.responseText;
            const json = JSON.parse(textResponse);

            if (json.hasOwnProperty("GraphicalMetrics") && json["GraphicalMetrics"].hasOwnProperty("errorResponse")) {
                ele._showYamlValidationErrorMessages(json.GraphicalMetrics.errorResponse);
            } else {
                ele._runYamlGeneratedReport(json.GraphicalMetrics);
            }
        }

        xhr.open("POST", url, true);
        if (!userName && authToken) {
            xhr.setRequestHeader(this.Constants.REQUEST_HEADERS.AUTHORIZATION, "Bearer " + authToken);
        }
        if (!userName && targetVolume) {
          xhr.setRequestHeader(
            this.Constants.REQUEST_HEADERS.TARGET_VOLUME,
            targetVolume
          );
        }
        xhr.send(yamlInput);
    }

    _getSybilAttribute = (attributeName) => {
        return (this.getAttribute(attributeName)) ? this.getAttribute(attributeName) : this[attributeName];
    }

    initParamsTags = () => {
        const wrapperId = this._getSybilAttribute(this.Constants.ATTRIBUTE.WRAPPER_ID);
        const paramContainer = document.createElement("div");
        paramContainer.setAttribute("id", "paramcontainer_" + wrapperId);
        const paramEl = document.createElement("div");
        paramEl.setAttribute("id", "parampane_" + wrapperId);
        paramEl.setAttribute("style", "max-width:30%; margin: 25px 50px 0px;");
        const runParamEl = document.createElement("input");
        runParamEl.setAttribute("type", "button");
        runParamEl.setAttribute("class", "btn btn-primary");
        runParamEl.setAttribute("id", "runwithparams_" + wrapperId);
        runParamEl.setAttribute(
            "style",
            "visibility: hidden; margin: 10px 50px 0px;"
        );
        runParamEl.value = "Run Report";

        const parent = document.getElementById(wrapperId).parentNode;

        paramContainer.appendChild(paramEl);
        paramContainer.appendChild(runParamEl);
        parent.appendChild(paramContainer);
    }

    _runReportWithParameters = (paramObj, report) => {
        paramObj.downloadParameterValues((pvs) => {
            const wrapperId = this._getSybilAttribute(this.Constants.ATTRIBUTE.WRAPPER_ID);
            report.setParameterValues(pvs);
            report.registerEventHandler(
                actuate.viewer.EventConstants.ON_EXCEPTION,
                this.errorHandler
            );
            document
                .getElementById("paramcontainer_" + wrapperId)
                .style.display = "none";

            report.submit(() => report.enableIV());
        });
    }

    parameterErrorHandler = (exception) => {
        alert(exception.getMessage());
    }
    errorHandler = (viewInstance, exception) => {
        alert(exception.getMessage());
    }

    static get observedAttributes() {
        return ["yaml", "authToken", "authtoken"];
    }

    get authToken() {
        return this.hasAttribute("authToken");
    }

    set authToken(value) {
        return this.setAttribute("authToken", value);
    }

    get authtoken() {
        return this.hasAttribute("authtoken");
    }

    set authtoken(value) {
        return this.setAttribute("authtoken", value);
    }

    get yaml() {
        return this.hasAttribute("yaml");
    }

    set yaml(value) {
        return this.setAttribute("yaml", value);
    }

    attributeChangedCallback(name, oldValue, newValue) {
        if((name === "yaml" || name === "authToken" || name === "authtoken") && newValue) {
            this._initComponent();
        }
    }
}

customElements.define('mbir-report', MBIRReport);
