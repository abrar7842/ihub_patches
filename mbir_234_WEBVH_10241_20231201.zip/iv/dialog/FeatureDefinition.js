/******************************************************************************
 *	Copyright (c) 2004 Actuate Corporation and others.
 *	All rights reserved. This program and the accompanying materials
 *	are made available under the terms of the Eclipse Public License v1.0
 *	which accompanies this distribution, and is available at
 *		http://www.eclipse.org/legal/epl-v10.html
 *
 *	@fileoverview This file defines class actuate.iv.constant
 *	@author Actuate Corporation - IV Team
 *	@version 10.0
 *****************************************************************************/
actuate.util.Package.define( "actuate.dialog" );

/**
 * Constant class serves as resource definition class for IV lazy loading use
 * @class This class serves as the resource definition class for IV lazy loading use.
 * @name actuate.iv.FeatureDefinition
 */

actuate.resource.module.feature.define( "actuate.dialog",
{
	/**
	 * JavaScript resource alias definition which can be used by difference features.
	 */
	javaScriptAlias :
{
"LoginDialog"							: "/feature6150808849962786255.js",
"alias_js_loginDialog"					: "/feature7000602645631119444.js",

"CalendarDialog"                        : "/feature18000134896328174013.js",
"alias_js_calendarDialog"				: "/feature9173353993878558108.js",

"AdvancedFilterDialog"					: "/feature3111399635220421970.js",
"GadgetBuilderFilterTab"				: "/feature3816022587446361533.js",
"FilterManager"							: "/feature504762194047419203.js",
"SelectedFilterDialog"					: "/feature5000776317081879043.js",
"TopBottomNDialog" 						: "/feature10827582556190858388.js",
"ChartFilterDialog"						: "/feature3233193879926238052.js",
"CalculationDialog"						: "/feature15794954964525520635.js",
"FilePickerDialog"						: "/feature9777257815588526873.js",
"ChartCategoriesDialog"					: "/feature11774448458749151104.js",
"ChartSeriesDialog"						: "/feature6658414571852200087.js",
"alias_StylePreviewView"				: "/feature13443128809377624484.js",
"alias_StyleModel"						: "/feature12090125827927058622.js",
"alias_StyleMenus"						: "/feature9659806438192910372.js",
"StyleSelectionView"					: "/feature1286243108241477976.js",
"FontDialog"							: "/feature6139808249899700557.js",
"alias_js_fontDialog"					: "/feature5410513623488259063.js",
"FontDialogEx"							: "/feature9633443776608611947.js",
"alias_js_fontDialogEx"					: "/feature17585437790555903023.js",
"alias_js_advancedFilterDialog"			: "/feature17261845880484969805.js",
"alias_js_gadgetBuilderFilterDialog"	: "/feature8281536632585921648.js",
"alias_js_selectedFilterDialog"			: "/feature8341856725685406257.js",
"alias_js_topBottomNDialog"				: "/feature8173842908806111906.js",
"alias_js_chartFilterDialog"			: "/feature17319638081519893889.js",
"alias_js_chartCategoriesDialog"		: "/feature4755025947799413128.js",
"alias_js_calculationDialog"			: "/feature16544250827716397418.js",
"alias_js_filePickerDialog"				: "/feature15602189165298813876.js",
"alias_js_chartSeriesDialog"			: "/feature6538732591019002199.js",
"alias_stringFormattingDialog"			: "/feature17981037682975814843.js",
"alias_js_stringFormattingDialog"		: "/feature2096408174623943535.js",
"alias_numberFormattingDialog"			: "/feature10161027289063148697.js",
"alias_js_numberFormattingDialog"		: "/feature3116165338263018667.js",
"alias_dateFormattingDialog"			: "/feature1747149515271370478.js",
"alias_js_dateFormattingDialog"			: "/feature15259864475539748579.js",
"alias_dateTimeFormattingDialog"		: "/feature433180800525961764.js",
"alias_js_dateTimeFormattingDialog"		: "/feature11225389175545849861.js",
"alias_timeFormattingDialog"			: "/feature13082790087615698548.js",
"alias_js_timeFormattingDialog"			: "/feature6334330178022906260.js",
"alias_booleanFormattingDialog"			: "/feature4723754424311165172.js",
"alias_js_booleanFormattingDialog"		: "/feature2842301766291456948.js",
"ChartBuilderDialog" 					: "/feature1379693039857145012.js",
"alias_js_chartBuilderDialog"			: "/feature16364689224888399115.js",

"MeterFormatTab" 						: "/feature365246038293229551.js",
"alias_js_meterFormatDialog"	  		: "/feature11985927548525384939.js",
"MeterResponsiveFormatTab" 				: "/feature12112299354547255705.js",
"alias_js_meterResponsiveFormatDialog"	: "/feature13926920562073298146.js",
"MeterDataTab" 			           		: "/feature11083997270247518631.js",
"alias_js_meterDataDialog"	  			: "/feature15353949952930501308.js",
"BulletDataTab" 			           	: "/feature1935468329761944536.js",
"SparkLineDataTab" 			           	: "/feature6068072242941888444.js",
"alias_js_bulletDataDialog"	  			: "/feature3829794392471502525.js",
"alias_js_sparkLineDataDialog"	  		: "/feature11765184662697468256.js",
"LinearGaugeFormatTab" 			        : "/feature12027552986830699520.js",
"LinearGaugeResponsiveFormatTab" 		: "/feature9136250223174998119.js",
"alias_js_linearGaugeFormatDialog"	    : "/feature10850677211409710347.js",
"alias_js_linearGaugeResponsiveFormatDialog"	    : "/feature18129127298045008230.js",
"SparkLineFormatTab" 			        : "/feature5821458287256474154.js",
"alias_js_sparkLineFormatDialog"	    : "/feature8085562501242904360.js",
"SparkLineResponsiveFormatTab" 			        : "/feature14720025719021528607.js",
"alias_js_sparkLineResponsiveFormatDialog"	    : "/feature2284083132324612454.js",
"BulletFormatTab" 			        	: "/feature14656892182128578688.js",
"BulletResponsiveFormatTab" 		: "/feature16988841884719752088.js",
"alias_js_bulletFormatDialog"	    	: "/feature728720863285798606.js",
"alias_js_bulletResponsiveFormatDialog" : "/feature2624364348550449473.js",
"CylinderFormatTab" 			        : "/feature4720674483992608611.js",
"alias_js_cylinderFormatDialog"	    	: "/feature18091219676862266576.js",
"CylinderResponsiveFormatTab" 			: "/feature649435769665088379.js",
"alias_js_cylinderResponsiveFormatDialog"	    	: "/feature797500551191861398.js",
"ThermometerFormatTab" 			        : "/feature5854482033213475003.js",
"alias_js_thermometerFormatDialog"	    : "/feature15101496885483721467.js",
"ThermometerResponsiveFormatTab" 			        : "/feature10033079340312727457.js",
"alias_js_thermometerResponsiveFormatDialog"	    : "/feature2334333746642628038.js",
"FlashGadgetTypeTab" 			    	: "/feature6314166080439121063.js",
"alias_js_flashGadgetTypeDialog"		: "/feature15405840917740222138.js",
"FlashGadgetBuilder" 					: "/feature1420307820539861343.js",
"alias_js_flashGadgetBuilderDialog"		: "/feature10614128029398231288.js",

"ChartTypeTab"							: "/feature13025378392762041102.js",
"alias_js_chartTypeDialog"				: "/feature13008919693452486606.js",
"ChartWithAxisDataTab"					: "/feature14841610260848893586.js",
"alias_js_chartWithAxisDataTab"			: "/feature14212174749893596308.js",
"ChartWoAxisDataTab"					: "/feature15921485840799180952.js",
"alias_js_chartWoAxisDataTab"			: "/feature9289680410073499564.js",

"ParentChartWithAxisDataTab"			:"/feature3325396601964906388.js",

"BubbleChartWithAxisDataTab"	     	: "/feature7372689907414340513.js",
"alias_js_bubbleChartWithAxisDataTab" 	: "/feature15593501672241053628.js",

"DifferenceChartWithAxisDataTab"	     : "/feature17139218282666397094.js",
"alias_js_differenceChartWithAxisDataTab": "/feature17414793147300698702.js",

"GanttChartWithAxisDataTab"	     		: "/feature12300838173044548092.js",
"alias_js_ganttChartWithAxisDataTab" 	: "/feature13134736849970831583.js",

"StockChartWithAxisDataTab"	     	    : "/feature6292484384579954725.js",
"alias_js_stockChartWithAxisDataTab" 	: "/feature17941882985014917019.js",

"RadarChartWoAxisDataTab"	     		: "/feature11742463722469527427.js",
"alias_js_radarChartWoAxisDataTab" 		: "/feature11919018525656987666.js",

"HistogramChartWithAxisDataTab"	     	: "/feature1725758093265375069.js",
"alias_js_histogramChartWithAxisDataTab": "/feature16565595992314169912.js",

"TreemapChartWoAxisDataTab"	     		: "/feature15390069986776112410.js",
"alias_js_treemapChartWoAxisDataTab"	: "/feature10261613689095542171.js",

"HeatmapChartWithAxisDataTab"			: "/feature12902136050162276588.js",
"alias_js_heatmapChartWithAxisDataTab"	: "/feature8552213331467749723.js",

"ColumnChartFormatTab"					: "/feature17391516959268451354.js",
"alias_js_columnChartFormatDialog"		: "/feature10937432599545431025.js",
"ScatterChartFormatTab"					: "/feature12427393034734724543.js",
"alias_js_scatterChartFormatDialog"		: "/feature967546133411347289.js",
"AreaChartFormatTab"					: "/feature11081380502303026622.js",
"alias_js_areaChartFormatDialog"		: "/feature5083847176723247576.js",

"BubbleChartFormatTab"					: "/feature6711863600912403118.js",
"alias_js_bubbleChartFormatDialog"		: "/feature18433662606306178885.js",
"ApplyButtonBuilder" 					: "/feature11036416265944262100.js",
"alias_js_applyButtonDialog"			: "/feature2147044594727951735.js",
"ApplyButtonFormatTab"					: "/feature1267099913166241123.js",
"alias_js_applyButtonFormatDialog"		: "/feature9087302865344725033.js",

"DifferenceChartFormatTab"				: "/feature6179674712739769769.js",
"alias_js_differenceChartFormatDialog"	: "/feature9594224141799790797.js",
"GanttChartFormatTab"					: "/feature17964270779864554513.js",
"alias_js_ganttChartFormatDialog"		: "/feature16074847283769781549.js",
"StockChartFormatTab"					: "/feature9553982803924177891.js",
"alias_js_stockChartFormatDialog"		: "/feature9694369092274786699.js",
"PyramidChartFormatTab"					: "/feature12984003577983031060.js",
"alias_js_pyramidChartFormatDialog"		: "/feature15916801439092618725.js",
"RadarChartFormatTab"					: "/feature6853760769367655557.js",
"alias_js_radarChartFormatDialog"		: "/feature7814841445175416444.js",
"MeterChartFormatTab"					: "/feature13980244957734257618.js",
"alias_js_meterChartFormatDialog"		: "/feature320389951912481831.js",
"HistogramChartFormatTab"				: "/feature14498149516266100144.js",
"alias_js_histogramChartFormatDialog"	: "/feature18194019917659871512.js",
"HeatmapChartFormatTab"					: "/feature18396859930446288576.js",
"alias_js_heatmapChartFormatDialog"		: "/feature6988160232746957970.js",
"TreemapChartFormatTab"					: "/feature15576332419001052560.js",
"alias_js_treemapChartFormatDialog"	: "/feature14935219115219604314.js",

"SelectorBuilder" 					    : "/feature5622720420636821117.js",
"ReportLibraryBuilder"				    : "/feature540934745401671264.js",
"alias_js_selectorDialog"				: "/feature3143053351440635290.js",
"alias_js_reportLibraryDialog"			: "/feature8574246273630754251.js",
"SelectorDataTab" 					    : "/feature9576977182895981539.js",
"alias_js_selectorDataDialog"			: "/feature13766336780215495494.js",
"MultiSelectorDataTab" 				    : "/feature14088991256958676262.js",
"alias_js_multiSelectorDataDialog"		: "/feature4009422166599728499.js",
"SelectorDataVersionTab" 			    : "/feature7695671409074608812.js",
"alias_js_selectorDataVersionDialog"	: "/feature11739413716732869215.js",
"ReportLibraryDataTab"	 			    : "/feature17801014400601043009.js",
"alias_js_reportLibraryDataDialog"		: "/feature1839100145295321944.js",
"SelectorTypeTab" 					    : "/feature16888639011077421561.js",
"MultiSelectorTypeTab" 				    : "/feature15171677401537560852.js",
"alias_js_selectorTypeDialog"			: "/feature9526434284196898623.js",
"alias_js_multiSelectorTypeDialog"		: "/feature16728550723811879624.js",

"SelectorSliderFormatTab" 			    : "/feature2688967605641874018.js",
"alias_js_selectorSliderFormatDialog"	: "/feature17647794079218221438.js",
"MultiSelectorFormatTab" 			    : "/feature15709539916626684680.js",
"alias_js_multiSelectorFormatDialog"	: "/feature3855069488115107613.js",
"SelectorListFormatTab" 			    : "/feature1177488992902104956.js",
"alias_js_selectorListFormatDialog"		: "/feature10756042821228469774.js",
"SelectorDropdownFormatTab" 			: "/feature17085332982395069117.js",
"alias_js_selectorDropdownFormatDialog"	: "/feature15056361237297392558.js",
"SelectorCheckboxFormatTab" 			: "/feature17265185074177252212.js",
"alias_js_selectorCheckboxFormatDialog"	: "/feature8487119471550688776.js",
"SelectorRadioFormatTab" 			    : "/feature12190509962100513178.js",
"alias_js_selectorRadioFormatDialog"	: "/feature10659804611685326384.js",
"SelectorCalendarFormatTab" 			: "/feature16646030131991982271.js",
"alias_js_selectorCalendarFormatDialog"	: "/feature9715727800327969530.js",

"PieChartFormatTab"						: "/feature3493170989461371119.js",
"alias_js_pieChartFormatDialog"			: "/feature1904159618637912689.js",
"LineChartFormatTab"					: "/feature4611806787070415643.js",
"alias_js_lineChartFormatDialog"		: "/feature7181014506509906662.js",
"BarChartFormatTab"						: "/feature18253096438942376216.js",
"alias_js_barChartFormatDialog"			: "/feature15264749806807817621.js",
"DoughnutChartFormatTab"				: "/feature5674323281479428812.js",
"alias_js_doughnutChartFormatDialog"	: "/feature5059806758141078381.js",

"SummaryTableDataTab" 			       	: "/feature11591605586778070738.js",
"SummaryTableFormatTab" 			   	: "/feature6331361479595974496.js",
"alias_js_summaryTableDataDialog"	  	: "/feature14125611941454852267.js",
"alias_js_summaryTableFormatDialog"	  	: "/feature11214711168606019669.js",
"SummaryTableBuilder" 					: "/feature5121099207844022615.js",
"alias_js_summaryTableBuilderDialog"	: "/feature14708936877871015017.js",


"CrosstabDataTab" 			       		: "/feature7703858342758412294.js",
"alias_js_crosstabDataDialog"  			: "/feature7759586380214655141.js",
"CrosstabFormatTab"			      	 	: "/feature4794215664726820440.js",
"alias_js_crosstabFormatDialog"			: "/feature3659116581319015294.js",
"CrosstabBuilder" 						: "/feature5472146770847228569.js",
"alias_js_crosstabBuilderDialog"		: "/feature4103008609121376896.js",
"CrosstabDateGroupingDialog"			: "/feature13114032460228126486.js",

"ManageDataDialog" 						: "/feature1431153686576945438.js",
"alias_js_ManageDataDialog"				: "/feature9900882789878952878.js",
"DetailsDialog"							: "/feature7185102783742041005.js",

"ColumnListDialog"						: "/feature15891297190661821047.js",
"alias_js_columnListDialog"				: "/feature13984325606203496762.js",

"FlashGadgetFormatDialog"				: "/feature2000042293074910646.js",
"alias_js_flashGadgetFormatDialog"		: "/feature8687319776666751187.js",

"GenericPropsTab"						: "/feature5078659803827287684.js",
"alias_js_genericPropsDialog"			: "/feature10470193238137604749.js",

"FlexComponentBuilder"					: "/feature5440092164051000141.js",
"alias_js_flexcomponentBuilderDialog"	: "/feature1290799437754432808.js",
"FlexTableFormatTab"			    	: "/feature10070102622275326093.js",
"alias_js_flexTableFormatDialog"		: "/feature4370282167541908688.js",
"FlexComponentDataTab"		       		: "/feature11580032684785130786.js",
"alias_js_flexcomponentDataDialog" 		: "/feature10096819566260557626.js",
"FlexCrosstabFormatTab"			    	: "/feature2684306290460185584.js",
"alias_js_flexCrosstabFormatDialog"		: "/feature1345609570601500443.js",
"FlexCrosstabDataTab"			    	: "/feature8766497441026947398.js",
"alias_js_flexCrosstabDataDialog"		: "/feature8115464085231202737.js",

"HyperlinkBuilderDialog"				: "/feature5720592118873283465.js",
"alias_js_hyperlinkBuilderDialog"		: "/feature6087100752686437759.js",

"SingleMetricDataTab" 			       	: "/feature10943669751996186552.js",
"SingleMetricFormatTab" 			: "/feature17769517048029249442.js",
"SingleMetricBuilder" 				: "/feature16406528314702547605.js",
"alias_js_singleMetricDataDialog"	  	: "/feature2292951522961559917.js",
"alias_js_singleMetricFormatDialog"	  	: "/feature8332605051033417031.js",
"alias_js_singleMetricBuilderDialog"		: "/feature9050207595811095573.js",

"MapFormatTab"				: "/feature1399363899417109861.js",
"MapCollectionTab"				: "/feature18418448445880782011.js",
"MapDataTab" 			       	: "/feature12049666361767535574.js",
"alias_js_mapFormatDialog"	  	: "/feature8453502098539740431.js",
"alias_js_mapCollectionDialog"	  	: "/feature8328759689221957254.js",
"alias_js_mapDataDialog"	  	: "/feature16670846165405030103.js",


"CustomVizDataTab" 			       	: "/feature12493378214853833908.js",
"CustomVizFormatTab" 			: "/feature8420775656162111840.js",
"CustomVizBuilder" 				: "/feature7275313771346464022.js",
"alias_js_customVizDataDialog"	  	: "/feature15691742032208970136.js",
"alias_js_customVizFormatDialog"	  	: "/feature1045997863782225656.js",
"alias_js_customVizBuilderDialog"		: "/feature4789530282413936986.js"

},

	/**
	 * Feature defintions for on demand loading use
	 */
	AVAILABLE_FEATURES :
	{
		/**
		 * Feature definition for login dialog.
		 */
		LOGIN_DIALOG :
		{
			_javaScript			: ["LoginDialog", "alias_js_loginDialog"],
			_localizedString	: ["loginDialog", "baseDialog"],
 			_classInstance		: ["actuate.dialog.impl.helper.LoginDialog", "actuate.dialog.LoginDialog"],
			_publicClasses		:
			{
				"actuate.dialog.LoginDialog" : "actuate.dialog.impl.LoginDialog",
				"noClass" : null
			}
		},

		/**
		 * Feature definition for font dialog.
		 */
		FONT_DIALOG :
		{
			_javaScript			: ["alias_StyleMenus", "alias_StyleModel", "alias_StylePreviewView", "StyleSelectionView", "FontDialog", "alias_js_fontDialog"],
			_localizedString	: ["conditionFormatDialog", "fontDialog"],
 			_classInstance		: ["actuate.dialog.impl.helper.font.FontDialog", "actuate.dialog.FontDialog"],
  			_staticFunctions 	: [ "getInstance" ],
  			_cssFiles 			: new Array( "fontDialog.css" ),
  			_mobileCssFiles		: new Array( "fontDialog_mobile.css" ),
			_publicClasses		:
			{
				"actuate.dialog.FontDialog" : "actuate.dialog.impl.FontDialog",
				"noClass" : null
			}
		},

		/**
		 * Feature definition for column list dialog.
		 */
		COLUMNLIST_DIALOG :
		{
			_javaScript			: ["ColumnListDialog", "alias_js_columnListDialog"],
			_localizedString	: ["columnListDialog"],
 			_classInstance		: ["actuate.dialog.impl.helper.ColumnListDialog", "actuate.dialog.ColumnListDialog"],
  			_entryPoint			: "actuate.dialog.ColumnListDialog",
  			_mobileCssFiles		: new Array(
									"columnListDialog_mobile.css"
									),
			_publicClasses		:
			{
				"actuate.dialog.ColumnListDialog" : "actuate.dialog.impl.ColumnListDialog",
				"noClass" : null
			}
		},

		/**
		 * Feature definition for flash gadget format dialog
		 */
		FLASHGADGET_FORMAT_DIALOG :
		{
			_javaScript			: ["FlashGadgetFormatDialog", "alias_js_flashGadgetFormatDialog"],
			_localizedString	: ["FlashGadgetFormatDialog"],
 			_classInstance		: ["actuate.dialog.impl.helper.flashgadget.FlashGadgetFormatDialog", "actuate.dialog.FlashGadgetFormatDialog"],
  			_entryPoint			: "actuate.dialog.FlashGadgetFormatDialog",
			_publicClasses		:
			{
				"actuate.dialog.FlashGadgetFormatDialog" : "actuate.dialog.impl.flashgadget.FlashGadgetFormatDialog",
				"noClass" : null
			}
		},


		/**
		 * Feature definition for advanced font dialog.
		 */
		FONT_DIALOG_EX :
		{
			_javaScript			: ["alias_StyleMenus", "alias_StyleModel", "alias_StylePreviewView", "StyleSelectionView", "FontDialogEx", "alias_js_fontDialogEx"],
			_html				: ["FontDialogEx"],
			_localizedString	: ["conditionFormatDialog", "fontDialog"],
 			_classInstance		: ["actuate.dialog.impl.helper.font.FontDialogEx", "actuate.dialog.font.FontDialogEx"],
  			_entryPoint			: "actuate.dialog.font.FontDialogEx",
  			_cssFiles 			: new Array(
  										"fontDialogEx.css"
								),
			_publicClasses		:
			{
				"actuate.dialog.font.FontDialogEx" : "actuate.dialog.impl.font.FontDialogEx",
				"noClass" : null
			}
		},

		CHART_DATA_TAB_WITHAXIS_DIALOG:
		{
			_javaScript 		: [ "ChartWithAxisDataTab", "alias_js_chartWithAxisDataTab" ],
			_localizedString 	: [ "chartBuilder", "common.dataTab" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.chartbuilder.ChartWithAxisDataTab" ],
			_publicClasses		:
			{
				"actuate.dialog.ChartWithAxisDataDialog":"actuate.dialog.impl.chartbuilder.ChartWithAxisDataDialog",
				"noClass" : null
			}
		},

		HISTOGRAM_CHART_DATA_TAB_WITHAXIS_DIALOG:
		{
			_javaScript 		: [ "ParentChartWithAxisDataTab", "HistogramChartWithAxisDataTab", "alias_js_histogramChartWithAxisDataTab" ],
			_localizedString 	: [ "chartBuilder", "common.dataTab" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.chartbuilder.HistogramChartWithAxisDataTab" ],
			_publicClasses		:
			{
				"actuate.dialog.HistogramChartWithAxisDataDialog":"actuate.dialog.impl.chartbuilder.HistogramChartWithAxisDataDialog",
				"noClass" : null
			},
			_hasDependency      : true
		},

		HEATMAP_CHART_DATA_TAB_WITHAXIS_DIALOG :
		{
			_javaScript			: ["ParentChartWithAxisDataTab", "alias_js_heatmapChartWithAxisDataTab", "HeatmapChartWithAxisDataTab"],
			_localizedString 	: [ "chartBuilder", "common.dataTab" ],
			_classInstance		: ["actuate.dialog.impl.helper.chartbuilder.HeatmapChartWithAxisDataTab"],
			_publicClasses		:
			{
				"actuate.dialog.HeatMapChartWithAxisDataDialog" : "actuate.dialog.impl.chartbuilder.HeatMapChartWithAxisDataDialog",
				"noClass" : null
			}
		},

		BUBBLE_CHART_DATA_TAB_WITHAXIS_DIALOG:
		{
			_javaScript 		: [ "ParentChartWithAxisDataTab", "BubbleChartWithAxisDataTab", "alias_js_bubbleChartWithAxisDataTab" ],
			_localizedString 	: [ "chartBuilder", "common.dataTab" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.chartbuilder.BubbleChartWithAxisDataTab" ],
			_publicClasses		:
			{
				"actuate.dialog.BubbleChartWithAxisDataDialog":"actuate.dialog.impl.chartbuilder.BubbleChartWithAxisDataDialog",
				"noClass" : null
			},
			_hasDependency      : true
		},

		DIFFERENCE_CHART_DATA_TAB_WITHAXIS_DIALOG:
		{
			_javaScript 		: [ "ParentChartWithAxisDataTab", "DifferenceChartWithAxisDataTab", "alias_js_differenceChartWithAxisDataTab" ],
			_localizedString 	: [ "chartBuilder", "common.dataTab" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.chartbuilder.DifferenceChartWithAxisDataTab" ],
			_publicClasses		:
			{
				"actuate.dialog.DifferenceChartWithAxisDataDialog":"actuate.dialog.impl.chartbuilder.DifferenceChartWithAxisDataDialog",
				"noClass" : null
			},
			_hasDependency      : true
		},

		GANTT_CHART_DATA_TAB_WITHAXIS_DIALOG:
		{
			_javaScript 		: [ "ParentChartWithAxisDataTab", "GanttChartWithAxisDataTab", "alias_js_ganttChartWithAxisDataTab" ],
			_localizedString 	: [ "chartBuilder", "common.dataTab" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.chartbuilder.GanttChartWithAxisDataTab" ],
			_publicClasses		:
			{
				"actuate.dialog.GanttChartWithAxisDataDialog":"actuate.dialog.impl.chartbuilder.GanttChartWithAxisDataDialog",
				"noClass" : null
			},
			_hasDependency      : true
		},

		STOCK_CHART_DATA_TAB_WITHAXIS_DIALOG:
		{
			_javaScript 		: [ "ParentChartWithAxisDataTab", "StockChartWithAxisDataTab", "alias_js_stockChartWithAxisDataTab" ],
			_localizedString 	: [ "chartBuilder", "common.dataTab" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.chartbuilder.StockChartWithAxisDataTab" ],
			_publicClasses		:
			{
				"actuate.dialog.StockChartWithAxisDataDialog":"actuate.dialog.impl.chartbuilder.StockChartWithAxisDataDialog",
				"noClass" : null
			},
			_hasDependency      : true
		},

		CHART_DATA_TAB_WOAXIS_DIALOG:
		{
			_javaScript 		: [ "ChartWoAxisDataTab", "alias_js_chartWoAxisDataTab" ],
			_localizedString 	: [ "chartBuilder", "common.dataTab" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.chartbuilder.ChartWoAxisDataTab" ],
			_publicClasses		:
			{
				"actuate.dialog.ChartWoAxisDataDialog":"actuate.dialog.impl.chartbuilder.ChartWoAxisDataDialog",
				"noClass" : null
			}
		},

		RADAR_CHART_DATA_TAB_WOAXIS_DIALOG:
		{
			_javaScript 		: [ "RadarChartWoAxisDataTab", "alias_js_radarChartWoAxisDataTab" ],
			_localizedString 	: [ "chartBuilder", "common.dataTab" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.chartbuilder.RadarChartWoAxisDataTab" ],
			_publicClasses		:
			{
				"actuate.dialog.RadarChartWoAxisDataDialog":"actuate.dialog.impl.chartbuilder.RadarChartWoAxisDataDialog",
				"noClass" : null
			}
		},

		TREEMAP_CHART_DATA_TAB_WOAXIS_DIALOG:
		{
			_javaScript 		: [ "TreemapChartWoAxisDataTab", "alias_js_treemapChartWoAxisDataTab" ],
			_localizedString 	: [ "chartBuilder", "common.dataTab" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.chartbuilder.TreemapChartWoAxisDataTab" ],
			_publicClasses		:
			{
				"actuate.dialog.TreemapChartWoAxisDataDialog":"actuate.dialog.impl.chartbuilder.TreemapChartWoAxisDataDialog",
				"noClass" : null
			},
			_hasDependency      : true
		},

		GENERIC_PROPS_TAB_DIALOG:
		{
			_javaScript 		: [ "GenericPropsTab", "alias_js_genericPropsDialog" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.GenericPropsTab" ],
			_publicClasses		:
			{
				"actuate.dialog.GenericPropsDialog":"actuate.dialog.impl.GenericPropsDialog",
				"noClass" : null
			}
		},

		/**
		 * Feature definition for chart type dialog.
		 */
		CHART_TYPE_TAB_DIALOG :
		{
			_javaScript			: ["alias_js_chartTypeDialog", "ChartTypeTab"],
			_localizedString 	: [ "chartBuilder" ],
			_classInstance		: ["actuate.dialog.impl.helper.chartbuilder.ChartTypeTab"],
			_publicClasses		:
			{
				"actuate.dialog.ChartTypeDialog" : "actuate.dialog.impl.chartbuilder.ChartTypeDialog",
				"noClass" : null
			}
		},

		/**
		 * Feature definition for column chart format dialog.
		 */
		COLUMN_CHART_FORMAT_TAB_DIALOG :
		{
			_javaScript			: ["alias_js_columnChartFormatDialog", "ColumnChartFormatTab", "alias_StyleModel"],
			_localizedString 	: [ "chartBuilder" ],
			_classInstance		: ["actuate.dialog.impl.helper.chartbuilder.ColumnChartFormatTab"],
			_publicClasses		:
			{
				"actuate.dialog.ColumnChartFormatDialog" : "actuate.dialog.impl.chartbuilder.ColumnChartFormatDialog",
				"noClass" : null
			}
		},

		/**
		 * Feature definition for column chart format dialog.
		 */
		PIE_CHART_FORMAT_TAB_DIALOG :
		{
			_javaScript			: ["alias_js_pieChartFormatDialog", "PieChartFormatTab", "alias_StyleModel"],
			_localizedString 	: [ "chartBuilder" ],
			_classInstance		: ["actuate.dialog.impl.helper.chartbuilder.PieChartFormatTab"],
			_publicClasses		:
			{
				"actuate.dialog.PieChartFormatDialog" : "actuate.dialog.impl.chartbuilder.PieChartFormatDialog",
				"noClass" : null
			}
		},

		/**
		 * Feature definition for column chart format dialog.
		 */
		LINE_CHART_FORMAT_TAB_DIALOG :
		{
			_javaScript			: ["alias_js_lineChartFormatDialog", "LineChartFormatTab", "alias_StyleModel"],
			_localizedString 	: [ "chartBuilder" ],
			_classInstance		: ["actuate.dialog.impl.helper.chartbuilder.LineChartFormatTab"],
			_publicClasses		:
			{
				"actuate.dialog.LineChartFormatDialog" : "actuate.dialog.impl.chartbuilder.LineChartFormatDialog",
				"noClass" : null
			}
		},

		/**
		 * Feature definition for column chart format dialog.
		 */
		BAR_CHART_FORMAT_TAB_DIALOG :
		{
			_javaScript			: ["alias_js_barChartFormatDialog", "BarChartFormatTab", "alias_StyleModel"],
			_localizedString 	: [ "chartBuilder" ],
			_classInstance		: ["actuate.dialog.impl.helper.chartbuilder.BarChartFormatTab"],
			_publicClasses		:
			{
				"actuate.dialog.BarChartFormatDialog" : "actuate.dialog.impl.chartbuilder.BarChartFormatDialog",
				"noClass" : null
			}
		},

		/**
		 * Feature definition for column chart format dialog.
		 */
		DOUGHNUT_CHART_FORMAT_TAB_DIALOG :
		{
			_javaScript			: ["alias_js_doughnutChartFormatDialog", "DoughnutChartFormatTab", "alias_StyleModel"],
			_localizedString 	: [ "chartBuilder" ],
			_classInstance		: ["actuate.dialog.impl.helper.chartbuilder.DoughnutChartFormatTab"],
			_publicClasses		:
			{
				"actuate.dialog.DoughnutChartFormatDialog" : "actuate.dialog.impl.chartbuilder.DoughnutChartFormatDialog",
				"noClass" : null
			}
		},

		/**
		 * Feature definition for scatter chart format dialog.
		 */
		SCATTER_CHART_FORMAT_TAB_DIALOG :
		{
			_javaScript			: ["alias_js_scatterChartFormatDialog", "ScatterChartFormatTab", "alias_StyleModel"],
			_localizedString 	: [ "chartBuilder" ],
			_classInstance		: ["actuate.dialog.impl.helper.chartbuilder.ScatterChartFormatTab"],
			_publicClasses		:
			{
				"actuate.dialog.ScatterChartFormatDialog" : "actuate.dialog.impl.chartbuilder.ScatterChartFormatDialog",
				"noClass" : null
			}
		},

		/**
		 * Feature definition for area chart format dialog.
		 */
		AREA_CHART_FORMAT_TAB_DIALOG :
		{
			_javaScript			: ["alias_js_areaChartFormatDialog", "AreaChartFormatTab", "alias_StyleModel"],
			_localizedString 	: [ "chartBuilder" ],
			_classInstance		: ["actuate.dialog.impl.helper.chartbuilder.AreaChartFormatTab"],
			_publicClasses		:
			{
				"actuate.dialog.AreaChartFormatDialog" : "actuate.dialog.impl.chartbuilder.AreaChartFormatDialog",
				"noClass" : null
			}
		},

		/**
		 * Feature definition for bubble chart format dialog.
		 */
		BUBBLE_CHART_FORMAT_TAB_DIALOG :
		{
			_javaScript			: [ "alias_js_bubbleChartFormatDialog", "BubbleChartFormatTab", "alias_StyleModel"],
			_localizedString 	: [ "chartBuilder" ],
			_classInstance		: ["actuate.dialog.impl.helper.chartbuilder.BubbleChartFormatTab"],
			_publicClasses		:
			{
				"actuate.dialog.BubbleChartFormatDialog" : "actuate.dialog.impl.chartbuilder.BubbleChartFormatDialog",
				"noClass" : null
			}
		},

		/**
		 * Feature definition for difference chart format dialog.
		 */
		DIFFERENCE_CHART_FORMAT_TAB_DIALOG :
		{
			_javaScript			: [ "alias_js_differenceChartFormatDialog", "DifferenceChartFormatTab", "alias_StyleModel"],
			_localizedString 	: [ "chartBuilder" ],
			_classInstance		: ["actuate.dialog.impl.helper.chartbuilder.DifferenceChartFormatTab"],
			_publicClasses		:
			{
				"actuate.dialog.DifferenceChartFormatDialog" : "actuate.dialog.impl.chartbuilder.DifferenceChartFormatDialog",
				"noClass" : null
			}
		},

		/**
		 * Feature definition for gantt chart format dialog.
		 */
		GANTT_CHART_FORMAT_TAB_DIALOG :
		{
			_javaScript			: [ "alias_js_ganttChartFormatDialog", "GanttChartFormatTab", "alias_StyleModel"],
			_localizedString 	: [ "chartBuilder" ],
			_classInstance		: ["actuate.dialog.impl.helper.chartbuilder.GanttChartFormatTab"],
			_publicClasses		:
			{
				"actuate.dialog.GanttChartFormatDialog" : "actuate.dialog.impl.chartbuilder.GanttChartFormatDialog",
				"noClass" : null
			}
		},

		/**
		 * Feature definition for stock chart format dialog.
		 */
		STOCK_CHART_FORMAT_TAB_DIALOG :
		{
			_javaScript			: [ "alias_js_stockChartFormatDialog", "StockChartFormatTab", "alias_StyleModel"],
			_localizedString 	: [ "chartBuilder" ],
			_classInstance		: ["actuate.dialog.impl.helper.chartbuilder.StockChartFormatTab"],
			_publicClasses		:
			{
				"actuate.dialog.StockChartFormatDialog" : "actuate.dialog.impl.chartbuilder.StockChartFormatDialog",
				"noClass" : null
			}
		},

		/**
		 * Feature definition for histogram chart format dialog.
		 */
		HISTOGRAM_CHART_FORMAT_TAB_DIALOG :
		{
			_javaScript			: ["alias_js_histogramChartFormatDialog", "HistogramChartFormatTab", "alias_StyleModel"],
			_localizedString 	: [ "chartBuilder" ],
			_classInstance		: ["actuate.dialog.impl.helper.chartbuilder.HistogramChartFormatTab"],
			_publicClasses		:
			{
				"actuate.dialog.HistogramChartFormatDialog" : "actuate.dialog.impl.chartbuilder.HistogramChartFormatDialog",
				"noClass" : null
			}
		},

		/**
		 * Feature definition for heatmap chart format dialog.
		 */
		HEATMAP_CHART_FORMAT_TAB_DIALOG :
		{
			_javaScript			: ["alias_js_heatmapChartFormatDialog", "HeatmapChartFormatTab", "alias_StyleModel"],
			_localizedString 	: [ "chartBuilder" ],
			_classInstance		: ["actuate.dialog.impl.helper.chartbuilder.HeatmapChartFormatTab"],
			_publicClasses		:
			{
				"actuate.dialog.HeatmapChartFormatDialog" : "actuate.dialog.impl.chartbuilder.HeatmapChartFormatDialog",
				"noClass" : null
			}
		},

		/**
		 * Feature definition for treemap chart format dialog.
		 */
		TREEMAP_CHART_FORMAT_TAB_DIALOG :
		{
			_javaScript			: ["alias_js_treemapChartFormatDialog", "TreemapChartFormatTab", "alias_StyleModel"],
			_localizedString 	: [ "chartBuilder" ],
			_classInstance		: ["actuate.dialog.impl.helper.chartbuilder.TreemapChartFormatTab"],
			_publicClasses		:
			{
				"actuate.dialog.TreeMapChartFormatDialog" : "actuate.dialog.impl.chartbuilder.TreeMapChartFormatDialog",
				"noClass" : null
			}
		},

		/**
		 * Feature definition for pyramid chart format dialog.
		 */
		PYRAMID_CHART_FORMAT_TAB_DIALOG :
		{
			_javaScript			: [ "alias_js_pyramidChartFormatDialog", "PyramidChartFormatTab", "alias_StyleModel"],
			_localizedString 	: [ "chartBuilder" ],
			_classInstance		: ["actuate.dialog.impl.helper.chartbuilder.PyramidChartFormatTab"],
			_publicClasses		:
			{
				"actuate.dialog.PyramidChartFormatDialog" : "actuate.dialog.impl.chartbuilder.PyramidChartFormatDialog",
				"noClass" : null
			}
		},

		/**
		 * Feature definition for radar chart format dialog.
		 */
		RADAR_CHART_FORMAT_TAB_DIALOG :
		{
			_javaScript			: ["alias_js_radarChartFormatDialog", "RadarChartFormatTab", "alias_StyleModel"],
			_localizedString 	: [ "chartBuilder" ],
			_classInstance		: ["actuate.dialog.impl.helper.chartbuilder.RadarChartFormatTab"],
			_publicClasses		:
			{
				"actuate.dialog.RadarChartFormatDialog" : "actuate.dialog.impl.chartbuilder.RadarChartFormatDialog",
				"noClass" : null
			}
		},

		/**
		 * Feature definition for meter chart format dialog.
		 */
		METER_CHART_FORMAT_TAB_DIALOG :
		{
			_javaScript			: ["alias_js_meterChartFormatDialog", "MeterChartFormatTab", "alias_StyleModel"],
			_localizedString 	: [ "chartBuilder" ],
			_classInstance		: ["actuate.dialog.impl.helper.chartbuilder.MeterChartFormatTab"],
			_publicClasses		:
			{
				"actuate.dialog.MeterChartFormatDialog" : "actuate.dialog.impl.chartbuilder.MeterChartFormatDialog",
				"noClass" : null
			}
		},

		/**
		 * Feature definition for chart builder dialog.
		 */
		CHART_BUILDER_DIALOG :
		{
			_javaScript 		: [ "ChartBuilderDialog", "alias_js_chartBuilderDialog" ],
			_localizedString 	: [ "chartBuilder" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.chartbuilder.ChartBuilder", "actuate.dialog.ChartBuilderDialog" ],
  			_entryPoint			: "actuate.dialog.ChartBuilderDialog",
			_publicClasses		:
			{
				"actuate.dialog.ChartBuilderDialog":"actuate.dialog.impl.chartbuilder.ChartBuilderDialog",
				"noClass" : null
			}
		},

		/**
		 * flash gadget builder dialog
		 */
		FLASHGADGET_BUILDER_DIALOG :
		{
			_javaScript 		: [ "FlashGadgetBuilder", "alias_js_flashGadgetBuilderDialog" ],
			_localizedString 	: [ "flashGadgetBuilder" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.gadgetbuilder.FlashGadgetBuilder", "actuate.dialog.FlashGadgetBuilderDialog" ],
			_entryPoint			: "actuate.dialog.FlashGadgetBuilderDialog",
			_publicClasses		:
			{
				"actuate.dialog.FlashGadgetBuilderDialog":"actuate.dialog.impl.gadgetbuilder.FlashGadgetBuilderDialog",
				"noClass" : null
			}
		},

		/**
		 * 'format' tab for 'meter' gadget builder
		 */
		METER_FORMAT_TAB :
		{
			_javaScript 		: [ "MeterFormatTab", "alias_js_meterFormatDialog" ],
			_localizedString 	: [ "flashGadgetBuilderDialog" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.gadgetbuilder.MeterFormatTab" ],
			_publicClasses		:
			{
				"actuate.dialog.MeterFormatDialog":"actuate.dialog.impl.gadgetbuilder.MeterFormatDialog",
				"noClass" : null
			}
		},

		/**
		 * 'format' tab for responsive 'meter' gadget builder
		 */
		METER_RESPONSIVE_FORMAT_TAB :
		{
			_javaScript 		: [ "MeterResponsiveFormatTab", "alias_js_meterResponsiveFormatDialog" ],
			_localizedString 	: [ "flashGadgetBuilderDialog" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.gadgetbuilder.responsive.MeterResponsiveFormatTab" ],
			_publicClasses		:
			{
				"actuate.dialog.MeterResponsiveFormatDialog":"actuate.dialog.impl.gadgetbuilder.MeterResponsiveFormatDialog",
				"noClass" : null
			}
		},

		/**
		 * 'data' tab for 'meter' and 'linearGauge' gadget builder
		 */
		METER_DATA_TAB :
		{
			_javaScript 		: [ "MeterDataTab", "alias_js_meterDataDialog" ],
			_localizedString 	: [ "flashGadgetBuilderDialog", "common.dataTab", "numberFormattingDialog" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.gadgetbuilder.MeterDataTab" ],
			_publicClasses		:
			{
				"actuate.dialog.MeterDataDialog":"actuate.dialog.impl.gadgetbuilder.MeterDataDialog",
				"noClass" : null
			}
		},

		/**
		 * 'data' tab for 'bullet', 'cylinder', 'sparkline'  and 'thermometer' gadget builder
		 */
		BULLET_DATA_TAB :
		{
			_javaScript 		: [ "BulletDataTab", "alias_js_bulletDataDialog" ],
			_localizedString 	: [ "flashGadgetBuilderDialog", "common.dataTab" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.gadgetbuilder.BulletDataTab" ],
			_publicClasses		:
			{
				"actuate.dialog.BulletDataDialog":"actuate.dialog.impl.gadgetbuilder.BulletDataDialog",
				"noClass" : null
			}
		},

		/**
		 * 'data' tab for 'bullet', 'cylinder', 'sparkline'  and 'thermometer' gadget builder
		 */
		SPARKLINE_DATA_TAB :
		{
			_javaScript 		: [ "SparkLineDataTab", "alias_js_sparkLineDataDialog" ],
			_localizedString 	: [ "flashGadgetBuilderDialog", "common.dataTab" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.gadgetbuilder.SparkLineDataTab" ],
			_publicClasses		:
			{
				"actuate.dialog.SparkLineDataDialog":"actuate.dialog.impl.gadgetbuilder.SparkLineDataDialog",
				"noClass" : null
			}
		},

		/**
		 * 'format' tab for 'linear gauge' gadget builder
		 */
		LINEARGAUGE_FORMAT_TAB :
		{
			_javaScript 		: [ "LinearGaugeFormatTab", "alias_js_linearGaugeFormatDialog" ],
			_localizedString 	: [ "flashGadgetBuilderDialog" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.gadgetbuilder.LinearGaugeFormatTab" ],
			_publicClasses		:
			{
				"actuate.dialog.LinearGaugeFormatDialog":"actuate.dialog.impl.gadgetbuilder.LinearGaugeFormatDialog",
				"noClass" : null
			}
		},

		/**
		 * 'format' tab for Responsive 'linear gauge' gadget builder
		 */
		LINEARGAUGE_RESPONSIVE_FORMAT_TAB :
		{
			_javaScript 		: [ "LinearGaugeResponsiveFormatTab", "alias_js_linearGaugeResponsiveFormatDialog" ],
			_localizedString 	: [ "flashGadgetBuilderDialog" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.gadgetbuilder.responsive.LinearGaugeResponsiveFormatTab" ],
			_publicClasses		:
			{
				"actuate.dialog.LinearGaugeResponsiveFormatDialog":"actuate.dialog.impl.gadgetbuilder.responsive.LinearGaugeResponsiveFormatDialog",
				"noClass" : null
			}
		},

		/**
		 * 'format' tab for 'sparkline' gadget builder
		 */
		SPARKLINE_FORMAT_TAB :
		{
			_javaScript 		: [ "SparkLineFormatTab", "alias_js_sparkLineFormatDialog" ],
			_localizedString 	: [ "flashGadgetBuilderDialog" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.gadgetbuilder.SparkLineFormatTab" ],
			_publicClasses		:
			{
				"actuate.dialog.SparkLineFormatDialog":"actuate.dialog.impl.gadgetbuilder.SparkLineFormatDialog",
				"noClass" : null
			}
		},

		/**
		 * 'format' tab for responsive 'sparkline' gadget builder
		 */
		SPARKLINE_RESPONSIVE_FORMAT_TAB :
		{
			_javaScript 		: [ "SparkLineResponsiveFormatTab", "alias_js_sparkLineResponsiveFormatDialog" ],
			_localizedString 	: [ "flashGadgetBuilderDialog" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.gadgetbuilder.responsive.SparkLineResponsiveFormatTab" ],
			_publicClasses		:
			{
				"actuate.dialog.SparkLineResponsiveFormatDialog":"actuate.dialog.impl.gadgetbuilder.responsive.SparkLineResponsiveFormatDialog",
				"noClass" : null
			}
		},

		/**
		 * 'format' tab for 'bullet' gadget builder
		 */
		BULLET_FORMAT_TAB :
		{
			_javaScript 		: [ "BulletFormatTab", "alias_js_bulletFormatDialog" ],
			_localizedString 	: [ "flashGadgetBuilderDialog", "fontDialog" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.gadgetbuilder.BulletFormatTab" ],
			_publicClasses		:
			{
				"actuate.dialog.BulletFormatDialog":"actuate.dialog.impl.gadgetbuilder.BulletFormatDialog",
				"noClass" : null
			}
		},

		/**
		 * 'format' tab for responsive 'bullet' gadget builder
		 */
		BULLET_RESPONSIVE_FORMAT_TAB :
		{
			_javaScript 		: [ "BulletResponsiveFormatTab", "alias_js_bulletResponsiveFormatDialog" ],
			_localizedString 	: [ "flashGadgetBuilderDialog", "fontDialog" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.gadgetbuilder.responsive.BulletResponsiveFormatTab" ],
			_publicClasses		:
			{
				"actuate.dialog.BulletResponiveFormatDialog":"actuate.dialog.impl.gadgetbuilder.responsive.BulletResponiveFormatDialog",
				"noClass" : null
			}
		},

		/**
		 * 'format' tab for 'sparkline' gadget builder
		 */
		CYLINDER_FORMAT_TAB :
		{
			_javaScript 		: [ "CylinderFormatTab", "alias_js_cylinderFormatDialog" ],
			_localizedString 	: [ "flashGadgetBuilderDialog", "fontDialog" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.gadgetbuilder.CylinderFormatTab" ],
			_publicClasses		:
			{
				"actuate.dialog.CylinderFormatDialog":"actuate.dialog.impl.gadgetbuilder.CylinderFormatDialog",
				"noClass" : null
			}
		},

		/**
		 * 'format' tab for responsive 'cylinder' gadget builder
		 */
		CYLINDER_RESPONSIVE_FORMAT_TAB :
		{
			_javaScript 		: [ "CylinderResponsiveFormatTab", "alias_js_cylinderResponsiveFormatDialog" ],
			_localizedString 	: [ "flashGadgetBuilderDialog", "fontDialog" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.gadgetbuilder.responsive.CylinderResponsiveFormatTab" ],
			_publicClasses		:
			{
				"actuate.dialog.CylinderResponsiveFormatDialog":"actuate.dialog.impl.gadgetbuilder.responsive.CylinderResponsiveFormatDialog",
				"noClass" : null
			}
		},

		/**
		 * 'format' tab for 'sparkline' gadget builder
		 */
		APPLY_BUTTON_FORMAT_TAB :
		{
			_javaScript 		: [ "ApplyButtonFormatTab", "alias_js_applyButtonFormatDialog" ],
			_localizedString 	: [ "applyButtonBuilderDialog" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.applybuttonbuilder.ApplyButtonFormatTab" ],
			_publicClasses		:
			{
				"actuate.dialog.ApplyButtonFormatDialog":"actuate.dialog.impl.applybuttonbuilder.ApplyButtonFormatDialog",
				"noClass" : null
			}
		},

		/**
		 * 'format' tab for 'sparkline' gadget builder
		 */
		THERMOMETER_FORMAT_TAB :
		{
			_javaScript 		: [ "ThermometerFormatTab", "alias_js_thermometerFormatDialog" ],
			_localizedString 	: [ "flashGadgetBuilderDialog", "fontDialog" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.gadgetbuilder.ThermometerFormatTab" ],
			_publicClasses		:
			{
				"actuate.dialog.ThermometerFormatDialog":"actuate.dialog.impl.gadgetbuilder.ThermometerFormatDialog",
				"noClass" : null
			}
		},

		/**
		 * 'format' tab for responsive 'thermometer' gadget builder
		 */
		THERMOMETER_RESPONSIVE_FORMAT_TAB :
		{
			_javaScript 		: [ "ThermometerResponsiveFormatTab", "alias_js_thermometerResponsiveFormatDialog" ],
			_localizedString 	: [ "flashGadgetBuilderDialog", "fontDialog" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.gadgetbuilder.responsive.ThermometerResponsiveFormatTab" ],
			_publicClasses		:
			{
				"actuate.dialog.ThermometerResponsiveFormatDialog":"actuate.dialog.impl.gadgetbuilder.ThermometerResponsiveFormatDialog",
				"noClass" : null
			}
		},

		/**
		 * 'type' tab for flash gadget builder
		 */
		FLASHGADGET_TYPE_TAB :
		{
			_javaScript 		: [ "FlashGadgetTypeTab", "alias_js_flashGadgetTypeDialog" ],
			_localizedString 	: [ "flashGadgetBuilderDialog" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.gadgetbuilder.FlashGadgetTypeTab" ],
			_publicClasses		:
			{
				"actuate.dialog.FlashGadgetDialog":"actuate.dialog.impl.gadgetbuilder.FlashGadgetDialog",
				"noClass" : null
			}
		},

		SUMMARY_TABLE_BUILDER_DIALOG :
		{
			_javaScript 		: [ "SummaryTableBuilder", "alias_js_summaryTableBuilderDialog" ],
			_html 				: [ "SummaryTableBuilder" ],
			_localizedString 	: [ "tableBuilder", "summaryTableBuilder" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.summarytablebuilder.SummaryTableBuilder", "actuate.dialog.SummaryTableBuilderDialog" ],
  			_entryPoint			: "actuate.dialog.SummaryTableBuilderDialog",
			_publicClasses		:
			{
				"actuate.dialog.SummaryTableBuilderDialog":"actuate.dialog.impl.summarytablebuilder.SummaryTableBuilderDialog",
				"noClass" : null
			}
		},


		SUMMARY_TABLE_DATA_TAB :
		{
			_javaScript 		: [ "SummaryTableDataTab", "alias_js_summaryTableDataDialog" ],
			_localizedString 	: [ "tableBuilder", "summaryTableBuilder", "common.dataTab" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.summarytablebuilder.SummaryTableDataTab" ],
			_publicClasses		:
			{
				"actuate.dialog.SummaryTableDataDialog":"actuate.dialog.impl.summarytablebuilder.SummaryTableDataDialog",
				"noClass" : null
			}
		},

		SUMMARY_TABLE_FORMAT_TAB :
		{
			_javaScript 		: [ "SummaryTableFormatTab", "alias_js_summaryTableFormatDialog" ],
			_localizedString 	: [ "tableBuilder", "summaryTableBuilder", "fontDialog" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.summarytablebuilder.SummaryTableFormatTab" ],
			_publicClasses		:
			{
				"actuate.dialog.SummaryTableFormatDialog":"actuate.dialog.impl.summarytablebuilder.SummaryTableFormatDialog",
				"noClass" : null
			}
		},

		/**
		 * Feature definition for advanced filter dialog.
		 */
		ADVANCEDFILTERDIALOG_DIALOG :
		{
			_javaScript			: ["FilterManager", "AdvancedFilterDialog", "alias_js_advancedFilterDialog"],
			_html				: ["AdvancedFilterDialog"],
			_localizedString	: ["advancedFilterDialog", "filterDialog", "common"],
			_classInstance		: ["actuate.dialog.impl.helper.AdvancedFilterDialog"],
			_cssFiles 			: new Array(
									"advancedFilterDialog.css"
									),

  			_mobileCssFiles		: new Array(
									"advancedFilterDialog_mobile.css"
									),
			_publicClasses		:
			{
				"actuate.dialog.AdvancedFilterDialog" : "actuate.dialog.impl.AdvancedFilterDialog",
				"noClass" : null
			}
		},

		/**
		 * Feature definition for gadget builder filter dialog.
		 */
		GADGETBUILDER_FILTERDIALOG_DIALOG :
		{
			_javaScript			: ["FilterManager", "GadgetBuilderFilterTab", "alias_js_gadgetBuilderFilterDialog"],
			_html				: ["GadgetBuilderFilterDialog"],
			_localizedString	: ["gadgetBuilderFilterDialog", "advancedFilterDialog", "filterDialog", "common"],
			_classInstance		: ["actuate.dialog.impl.helper.GadgetBuilderFilterTab"],
			_cssFiles 			: new Array(
									"advancedFilterDialog.css"
									),
			_publicClasses		:
			{
				"actuate.dialog.GadgetBuilderFilterDialog" : "actuate.dialog.impl.GadgetBuilderFilterDialog",
				"noClass" : null
			}
		},

		/**
		 * Feature definition for simple filter dialog.
		 */
		FILTER_DIALOG :
		{
			_javaScript			: ["SelectedFilterDialog", "alias_js_selectedFilterDialog", "ChartFilterDialog", "alias_js_chartFilterDialog"],
			_html				: ["FilterDialog"],
			_localizedString	: ["filterDialog"],
			_classInstance		: ["actuate.dialog.impl.helper.SelectedFilterDialog", "actuate.dialog.impl.helper.ChartFilterDialog"],
			_cssFiles 			: new Array(
									"selectedFilterDialog.css",
									"chartFilterDialog.css"
									),
			_publicClasses		:
			{
				"actuate.dialog.ChartFilterDialog" : "actuate.dialog.impl.ChartFilterDialog",
				"actuate.dialog.SelectedFilterDialog" : "actuate.dialog.impl.SelectedFilterDialog",
				"noClass" : null
			}
		},

		/**
		 * Feature definition for top bottom n filter dialog.
		 */
		TOPBOTTOMN_DIALOG :
		{
			_javaScript			: ["TopBottomNDialog", "alias_js_topBottomNDialog"],
			_html				: ["TopBottomNDialog"],
			_localizedString	: ["filterDialog"],
			_classInstance		: ["actuate.dialog.impl.helper.TopBottomNDialog"],
			_cssFiles 			: new Array(
									"topBottomDialog.css"
									),
			_publicClasses		:
			{
				"actuate.dialog.TopBottomNDialog" : "actuate.dialog.impl.TopBottomNDialog",
				"noClass" : null
			}
		},


		/**
		 * Feature definition for chart categories dialog.
		 */
		CHART_CATEGORIES_DIALOG :
		{
			_javaScript			: ["ChartCategoriesDialog", "alias_js_chartCategoriesDialog"],
			_html				: ["ChartCategoriesDialog"],
			_localizedString	: ["chartCategoriesDialog"],
			_classInstance		: ["actuate.dialog.impl.helper.ChartCategoriesDialog"],
			_publicClasses		:
			{
				"actuate.dialog.ChartCategoriesDialog" : "actuate.dialog.impl.ChartCategoriesDialog",
				"noClass" : null
			}
		},

		/**
		 * Feature definition for chart series dialog.
		 */
		CHART_SERIES_DIALOG :
		{
			_javaScript			: ["ChartSeriesDialog", "alias_js_chartSeriesDialog"],
			_html				: ["ChartSeriesDialog"],
			_localizedString	: ["chartSeriesDialog"],
			_classInstance		: ["actuate.dialog.impl.helper.ChartSeriesDialog"],
			_publicClasses		:
			{
				"actuate.dialog.ChartSeriesDialog" : "actuate.dialog.impl.ChartSeriesDialog",
				"noClass" : null
			}
		},

		/**
		 * Feature definition for string formatting dialog.
		 */
		STRING_FORMAT_DIALOG :
		{
			_javaScript			: ["alias_stringFormattingDialog", "alias_js_stringFormattingDialog"],
			_html				: ["StringFormattingDialog"],
			_localizedString	: ["stringFormattingDialog"],
 			_classInstance		: ["actuate.dialog.impl.helper.format.StringFormattingDialog", "actuate.dialog.format.StringFormattingDialog"],
 			_entryPoint			: "actuate.dialog.format.StringFormattingDialog",
  			_cssFiles 			: new Array(
									"stringFormattingDialog.css"
									),
  			_mobileCssFiles		: new Array(
									"stringFormattingDialog_mobile.css"
									),
   			_publicClasses		:
			{
				"actuate.dialog.format.StringFormattingDialog" : "actuate.dialog.impl.format.StringFormattingDialog",
				"noClass" : null
			}
		},

		/**
		 * Feature definition for number formatting dialog.
		 */
		NUMBER_FORMAT_DIALOG :
		{
			_javaScript			: ["alias_numberFormattingDialog", "alias_js_numberFormattingDialog"],
			_html				: ["NumberFormattingDialog"],
			_localizedString	: ["numberFormattingDialog"],
 			_classInstance		: ["actuate.dialog.impl.helper.format.NumberFormattingDialog", "actuate.dialog.format.NumberFormattingDialog"],
  			_entryPoint			: "actuate.dialog.format.NumberFormattingDialog",
  			_cssFiles 			: new Array(
									"numberFormattingDialog.css"
									),
  			_mobileCssFiles		: new Array(
									"numberFormattingDialog_mobile.css"
									),
 			_publicClasses		:
			{
				"actuate.dialog.format.NumberFormattingDialog" : "actuate.dialog.impl.format.NumberFormattingDialog",
				"noClass" : null
			}
		},

		/**
		 * Feature definition for calculation dialog.
		 */
		CALCULATION_DIALOG :
		{
			_javaScript			: ["CalculationDialog", "alias_js_calculationDialog"],
			_localizedString	: ["calculationDialog"],
 			_classInstance		: ["actuate.dialog.impl.helper.CalculationDialog", "actuate.dialog.CalculationDialog"],
  			_staticFunctions 	: [ "getInstance" ],
  			_cssFiles 			: new Array( "calculationDailog.css" ),
 			_publicClasses		:
			{
				"actuate.dialog.CalculationDialog" : "actuate.dialog.impl.CalculationDialog",
				"noClass" : null
			}
		},

		/**
		 * Feature definition for file chooser dialog.
		 */
		FILEPICKER_DIALOG :
		{
			_javaScript			: ["FilePickerDialog", "alias_js_filePickerDialog"],
			_localizedString	: ["filePickerDialog"],
 			_classInstance		: ["actuate.dialog.impl.helper.filepicker.FilePickerDialog", "actuate.dialog.FilePickerDialog"],
  			_staticFunctions 	: [ "getInstance" ],
  			_cssFiles 			: new Array( "filePickerDialog.css" ),
			_publicClasses		:
			{
				"actuate.dialog.FilePickerDialog" : "actuate.dialog.impl.FilePickerDialog",
				"noClass" : null
			}
		},

		/**
		 * Feature definition for hyperlink dialog.
		 */
		HYPERLINK_BUILDER :
		{
			_javaScript			: ["HyperlinkBuilderDialog", "alias_js_hyperlinkBuilderDialog"],
			_html				: ["HyperlinkBuilderDialog"],
			_localizedString	: ["hyperlinkBuilderDialog", "baseDialog"],
 			_classInstance		: ["actuate.dialog.impl.helper.hyperlinkBuilder.HyperlinkBuilderDialog", "actuate.dialog.hyperlinkBuilder.HyperlinkBuilderDialog"],
  			_entryPoint			: "actuate.dialog.hyperlinkBuilder.HyperlinkBuilderDialog",
  			_cssFiles 			: new Array( "hyperlinkDialog.css" ),
 			_publicClasses		:
			{
				"actuate.dialog.hyperlinkBuilder.HyperlinkBuilderDialog" : "actuate.dialog.impl.hyperlinkBuilder.HyperlinkBuilderDialog",
				"noClass" : null
			}
		},

 		/**
 		 * Feature definition for date formatting dialog.
 		 */
 		DATE_FORMAT_DIALOG :
 		{
 			_javaScript			: ["alias_dateFormattingDialog", "alias_js_dateFormattingDialog"],
 			_html				: ["DateFormattingDialog"],
 			_localizedString	: [ "dateFormattingDialog" ],
 			_classInstance		: ["actuate.dialog.impl.helper.format.DateFormattingDialog", "actuate.dialog.format.DateFormattingDialog"],
 			_entryPoint			: "actuate.dialog.format.DateFormattingDialog",
  			_cssFiles 			: new Array(
									"dateFormattingDialog.css"
									),
  			_mobileCssFiles		: new Array(
									"dateFormattingDialog_mobile.css"
									),
  			_publicClasses		:
 			{
 				"actuate.dialog.format.DateFormattingDialog" : "actuate.dialog.impl.format.DateFormattingDialog",
 				"noClass" : null
 			}
 		},

 		/**
 		 * Feature definition for date time formatting dialog.
 		 */
		DATATIME_FORMAT_DIALOG :
		{
			_javaScript			: ["alias_dateTimeFormattingDialog", "alias_js_dateTimeFormattingDialog"],
			_html				: ["DateTimeFormattingDialog"],
			_localizedString	: ["dateTimeFormattingDialog"],
			_classInstance 		: ["actuate.dialog.impl.helper.format.DateTimeFormattingDialog", "actuate.dialog.format.DateTimeFormattingDialog"],
			_entryPoint			: "actuate.dialog.format.DateTimeFormattingDialog",
  			_cssFiles 			: new Array(
									"dateTimeFormattingDialog.css"
									),
  			_mobileCssFiles		: new Array(
									"dateTimeFormattingDialog_mobile.css"
									),
			_publicClasses		:
			{
				"actuate.dialog.format.DateTimeFormattingDialog" : "actuate.dialog.impl.format.DateTimeFormattingDialog",
				"noClass" : null
			}
		},

 		/**
 		 * Feature definition for time formatting dialog.
 		 */
		TIME_FORMAT_DIALOG :
		{
			_javaScript 		: ["alias_timeFormattingDialog", "alias_js_timeFormattingDialog"],
			_html				: ["TimeFormattingDialog"],
			_localizedString	: ["timeFormattingDialog" ],
			_classInstance		: ["actuate.dialog.impl.helper.format.TimeFormattingDialog", "actuate.dialog.format.TimeFormattingDialog"],
			_entryPoint			: "actuate.dialog.format.TimeFormattingDialog",
  			_cssFiles 			: new Array(
									"timeFormattingDialog.css"
									),
  			_mobileCssFiles		: new Array(
									"timeFormattingDialog_mobile.css"
									),
			_publicClasses		:
			{
				"actuate.dialog.format.TimeFormattingDialog" : "actuate.dialog.impl.format.TimeFormattingDialog",
				"noClass" : null
			}
		},

		/**
 		 * Feature definition for boolean formatting dialog.
		 */
		BOOLEAN_FORMAT_DIALOG :
		{
			_javaScript			: ["alias_booleanFormattingDialog", "alias_js_booleanFormattingDialog"],
			_html				: ["BooleanFormattingDialog"],
			_localizedString	: ["booleanFormattingDialog"],
			_classInstance		: ["actuate.dialog.impl.helper.format.BooleanFormattingDialog", "actuate.dialog.format.BooleanFormattingDialog"],
  			_entryPoint			: "actuate.dialog.format.BooleanFormattingDialog",
  			_cssFiles 			: new Array(
									"booleanFormattingDialog.css"
									),
  			_mobileCssFiles		: new Array(
									"booleanFormattingDialog_mobile.css"
									),
			_publicClasses		:
			{
				"actuate.dialog.format.BooleanFormattingDialog" : "actuate.dialog.impl.format.BooleanFormattingDialog",
				"noClass" : null
			}
		},

		APPLY_BUTTON_DIALOG :
		{
			_javaScript 		: [ "ApplyButtonBuilder", "alias_js_applyButtonDialog" ],
			_localizedString 	: [ "applyButtonBuilder" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.applybuttonbuilder.ApplyButtonBuilder","actuate.dialog.ApplyButtonDialog"],
			_entryPoint			: "actuate.dialog.ApplyButtonDialog",
			_publicClasses		:
			{
				"actuate.dialog.ApplyButtonDialog":"actuate.dialog.impl.applybuttonbuilder.ApplyButtonDialog",
				"noClass" : null
			}
		},

		/**
		 * Selector builder dialog
		 */
		SELECTOR_DIALOG :
		{
			_javaScript 		: [ "SelectorBuilder", "alias_js_selectorDialog" ],
			_html 				: [ "SelectorBuilder", "BooleanFormattingDialog", "StringFormattingDialog", "NumberFormattingDialog", "DateFormattingDialog", "TimeFormattingDialog", "DateTimeFormattingDialog" ],
			_localizedString 	: [ "Utility", "SelectorBuilder", "booleanFormattingDialog", "stringFormattingDialog", "numberFormattingDialog", "dateFormattingDialog", "timeFormattingDialog", "dateTimeFormattingDialog" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.selectorbuilder.SelectorBuilder","actuate.dialog.SelectorDialog"],
			_entryPoint			: "actuate.dialog.SelectorDialog",
			_publicClasses		:
			{
				"actuate.dialog.SelectorDialog":"actuate.dialog.impl.selectorbuilder.SelectorDialog",
				"noClass" : null
			}
		},

		/**
		 * ReportLibrary builder dialog
		 */
		REPORTLIBRARY_DIALOG :
		{
			_javaScript 		: [ "ReportLibraryBuilder", "alias_js_reportLibraryDialog" ],
			_localizedString 	: [ "Utility", "reportLibraryBuilder" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.reportlibrarybuilder.ReportLibraryBuilder", "actuate.dialog.ReportLibraryDialog"],
			_entryPoint			: "actuate.dialog.ReportLibraryDialog",
			_publicClasses		:
			{
				"actuate.dialog.ReportLibraryDialog":"actuate.dialog.impl.reportlibrarybuilder.ReportLibraryDialog",
				"noClass" : null
			}
		},

		/**
		 * 'data' tab for 'selector' gadget builder
		 */
		SELECTOR_DATA_TAB :
		{
			_javaScript 		: [ "SelectorDataTab", "alias_js_selectorDataDialog", "FilterManager" ],
			_localizedString 	: [ "Utility","selectorDialog", "selectorBuilder.dataTab", "selectorBuilder.typeTab", "selectorBuilder.formatTab", "common.dataTab", "filterDialog" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.selectorbuilder.SelectorDataTab" ],
			_publicClasses		:
			{
				"actuate.dialog.SelectorDataDialog":"actuate.dialog.impl.selectorbuilder.SelectorDataDialog",
				"noClass" : null
			}
		},


		/**
		 * 'data' tab for 'selector' gadget builder
		 */
		MULTI_SELECTOR_DATA_TAB :
		{
			_javaScript 		: [ "MultiSelectorDataTab", "alias_js_multiSelectorDataDialog", "FilterManager" ],
			_localizedString 	: [ "Utility","selectorDialog", "selectorBuilder.dataTab","selectorBuilder.multidataTab", "selectorBuilder.typeTab", "selectorBuilder.formatTab", "common.dataTab", "filterDialog" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.selectorbuilder.MultiSelectorDataTab" ],
			_publicClasses		:
			{
				"actuate.dialog.MultiSelectorDataDialog":"actuate.dialog.impl.selectorbuilder.MultiSelectorDataDialog",
				"noClass" : null
			}
		},

		/**
		 * 'data' tab for 'version-selector' gadget builder
		 */
		SELECTOR_DATA_VERSION_TAB :
		{
			_javaScript 		: [ "SelectorDataVersionTab", "alias_js_selectorDataVersionDialog" ],
			_localizedString 	: [ "Utility", "selectorDialog", "selectorBuilder.dataTab", "common.dataTab" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.selectorbuilder.SelectorDataVersionTab" ],
			_publicClasses		:
			{
				"actuate.dialog.SelectorDataVersionDialog":"actuate.dialog.impl.selectorbuilder.SelectorDataVersionDialog",
				"noClass" : null
			}
		},

		/**
		 * 'data' tab for 'reportlibrary' gadget builder
		 */
		REPORTLIBRARY_DATA_TAB :
		{
			_javaScript 		: [ "ReportLibraryDataTab", "alias_js_reportLibraryDataDialog" ],
			_localizedString 	: [ "Utility", "reportLibraryBuilder" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.reportlibrarybuilder.ReportLibraryDataTab" ],
			_publicClasses		:
			{
				"actuate.dialog.ReportLibraryDataDialog":"actuate.dialog.impl.reportlibrarybuilder.ReportLibraryDataDialog",
				"noClass" : null
			}
		},

		/**
		 * 'type' tab for 'selector' gadget builder
		 */
		SELECTOR_TYPE_TAB :
		{
			_javaScript 		: [ "SelectorTypeTab", "alias_js_selectorTypeDialog" ],
			_localizedString 	: [ "Utility","selectorDialog" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.selectorbuilder.SelectorTypeTab" ],
			_cssFiles 			: new Array(
									"selectorType.css"
									),
			_publicClasses		:
			{
				"actuate.dialog.SelectorTypeDialog":"actuate.dialog.impl.selectorbuilder.SelectorTypeDialog",
				"noClass" : null
			}
		},

		/**
		 * 'type' tab for 'selector' gadget builder
		 */
		MULTI_SELECTOR_TYPE_TAB :
		{
			_javaScript 		: [ "MultiSelectorTypeTab", "alias_js_multiSelectorTypeDialog" ],
			_localizedString 	: [ "Utility","selectorDialog" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.selectorbuilder.MultiSelectorTypeTab" ],
			_cssFiles 			: new Array(
									"selectorType.css"
									),
			_publicClasses		:
			{
				"actuate.dialog.MultiSelectorTypeDialog":"actuate.dialog.impl.selectorbuilder.MultiSelectorTypeDialog",
				"noClass" : null
			}
		},

		/**
		 * 'format' tab for 'slider selector' gadget builder
		 */
		MULTI_SELECTOR_FORMAT_TAB :
		{
			_javaScript 		: [ "MultiSelectorFormatTab", "alias_js_multiSelectorFormatDialog" ],
			_localizedString 	: [ "Utility","selectorDialog" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.selectorbuilder.MultiSelectorFormatTab" ],
			_publicClasses		:
			{
				"actuate.dialog.MultiSelectorFormatDialog":"actuate.dialog.impl.selectorbuilder.MultiSelectorFormatDialog",
				"noClass" : null
			}
		},

		/**
		 * 'format' tab for 'slider selector' gadget builder
		 */
		SELECTOR_SLIDER_FORMAT_TAB :
		{
			_javaScript 		: [ "SelectorSliderFormatTab", "alias_js_selectorSliderFormatDialog" ],
			_localizedString 	: [ "Utility","selectorDialog" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.selectorbuilder.SelectorSliderFormatTab" ],
			_publicClasses		:
			{
				"actuate.dialog.SelectorSliderFormatDialog":"actuate.dialog.impl.selectorbuilder.SelectorSliderFormatDialog",
				"noClass" : null
			}
		},

		/**
		 * 'format' tab for 'list selector' gadget builder
		 */
		SELECTOR_LIST_FORMAT_TAB :
		{
			_javaScript 		: [ "SelectorListFormatTab", "alias_js_selectorListFormatDialog" ],
			_localizedString 	: [ "Utility","selectorDialog" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.selectorbuilder.SelectorListFormatTab" ],
			_publicClasses		:
			{
				"actuate.dialog.SelectorListFormatDialog":"actuate.dialog.impl.selectorbuilder.SelectorListFormatDialog",
				"noClass" : null
			}
		},

		/**
		 * 'format' tab for 'dropdown selector' gadget builder
		 */
		SELECTOR_DROPDOWN_FORMAT_TAB :
		{
			_javaScript 		: [ "SelectorDropdownFormatTab", "alias_js_selectorDropdownFormatDialog" ],
			_localizedString 	: [ "Utility","selectorDialog" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.selectorbuilder.SelectorDropdownFormatTab" ],
			_publicClasses		:
			{
				"actuate.dialog.SelectorDropdownFormatDialog":"actuate.dialog.impl.selectorbuilder.SelectorDropdownFormatDialog",
				"noClass" : null
			}
		},

		/**
		 * 'format' tab for 'checkbox selector' gadget builder
		 */
		SELECTOR_CHECKBOX_FORMAT_TAB :
		{
			_javaScript 		: [ "SelectorCheckboxFormatTab", "alias_js_selectorCheckboxFormatDialog" ],
			_localizedString 	: [ "Utility","selectorDialog" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.selectorbuilder.SelectorCheckboxFormatTab" ],
			_publicClasses		:
			{
				"actuate.dialog.SelectorCheckboxFormatDialog":"actuate.dialog.impl.selectorbuilder.SelectorCheckboxFormatDialog",
				"noClass" : null
			}
		},

		/**
		 * 'format' tab for 'radio selector' gadget builder
		 */
		SELECTOR_RADIO_FORMAT_TAB :
		{
			_javaScript 		: [ "SelectorRadioFormatTab", "alias_js_selectorRadioFormatDialog" ],
			_localizedString 	: [ "Utility","selectorDialog" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.selectorbuilder.SelectorRadioFormatTab" ],
			_publicClasses		:
			{
				"actuate.dialog.SelectorRadioFormatDialog":"actuate.dialog.impl.selectorbuilder.SelectorRadioFormatDialog",
				"noClass" : null
			}
		},

		/**
		 * 'format' tab for 'radio selector' gadget builder
		 */
		SELECTOR_CALENDAR_FORMAT_TAB :
		{
			_javaScript 		: [ "SelectorCalendarFormatTab", "alias_js_selectorCalendarFormatDialog" ],
			_localizedString 	: [ "Utility", "selectorDialog" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.selectorbuilder.SelectorCalendarFormatTab" ],
			_publicClasses		:
			{
				"actuate.dialog.SelectorCalendarFormatDialog" : "actuate.dialog.impl.selectorbuilder.SelectorCalendarFormatDialog",
				"noClass" : null
			}
		},

		CROSSTAB_BUILDER_DIALOG :
		{
			_javaScript 		: [ "CrosstabBuilder", "alias_js_crosstabBuilderDialog" ],
			_html 				: [ "CrosstabBuilder" ],
			_localizedString 	: [ "crosstabBuilderDialog" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.crosstabbuilder.CrosstabBuilder", "actuate.dialog.CrosstabBuilderDialog" ],
  			_entryPoint			: "actuate.dialog.CrosstabBuilderDialog",
			_publicClasses		:
			{
				"actuate.dialog.CrosstabBuilderDialog":"actuate.dialog.impl.crosstabbuilder.CrosstabBuilderDialog",
				"noClass" : null
			}
		},

		/**
		 * 'data' tab for crosstab builder
		 */
		CROSSTAB_DATA_TAB :
		{
			_javaScript 		: [ "CrosstabDateGroupingDialog", "CrosstabDataTab", "alias_js_crosstabDataDialog" ],
			_localizedString 	: [ "crosstabBuilderDialog", "common.dataTab", "crosstabDateGroupingDialog" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.crosstabbuilder.CrosstabDataTab" ],
			_cssFiles 			: new Array(
									"crosstabDataTab.css"
									),
			_publicClasses		:
			{
				"actuate.dialog.CrosstabDataDialog":"actuate.dialog.impl.crosstabbuilder.CrosstabDataDialog",
				"noClass" : null
			}
		},

		/**
		 * 'format' tab for crosstab builder
		 */
		CROSSTAB_FORMAT_TAB :
		{
			_javaScript 		: [ "CrosstabFormatTab", "alias_js_crosstabFormatDialog" ],
			_localizedString 	: [ "crosstabBuilderDialog" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.crosstabbuilder.CrosstabFormatTab" ],
			_cssFiles 			: new Array(
									"crosstabFormatTab.css"
									),
			_publicClasses		:
			{
				"actuate.dialog.CrosstabFormatDialog":"actuate.dialog.impl.crosstabbuilder.CrosstabFormatDialog",
				"noClass" : null
			}
		},

		/**
		 * Manage data dialog
		 */
		MANAGE_DATA_DIALOG :
		{
			_javaScript 		: [ "ManageDataDialog", "alias_js_ManageDataDialog", "DetailsDialog" ],
			_localizedString 	: [ "manageDataDialog" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.datamanager.ManageDataDialog","actuate.dialog.datamanager.ManageDataDialog","actuate.dialog.impl.helper.datamanager.DetailsDialog"],
			_entryPoint			: "actuate.dialog.datamanager.ManageDataDialog",
			_cssFiles 			: new Array(
									"managedata.css"
									),
			_publicClasses		:
			{
				"actuate.dialog.datamanager.ManageDataDialog":"actuate.dialog.impl.datamanager.ManageDataDialog",
				"noClass" : null
			}
		},

		/**
		 * Feature definition for calendar dialog.
		 */
		CALENDAR_DIALOG :
		{
			_javaScript			: ["CalendarDialog", "alias_js_calendarDialog"],
			_html				: ["CalendarDialog"],
			_localizedString	: ["calendarDialog"],
			_classInstance		: ["actuate.dialog.impl.helper.CalendarDialog"],
			_publicClasses		:
			{
				"actuate.dialog.CalendarDialog" : "actuate.dialog.impl.CalendarDialog",
				"noClass" : null
			}
		},

		FLEXCOMPONENT_BUILDER_DIALOG :
		{
			_javaScript 		: [ "FlexComponentBuilder", "alias_js_flexcomponentBuilderDialog" ],
			_html 				: [ "FlexComponentBuilder" ],
			_localizedString 	: [ "FlexComponentBuilderDialog" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.flexcomponentbuilder.FlexComponentBuilder", "actuate.dialog.FlexComponentBuilderDialog" ],
  			_entryPoint			: "actuate.dialog.FlexComponentBuilderDialog",
			_publicClasses		:
			{
				"actuate.dialog.FlexComponentBuilderDialog":"actuate.dialog.impl.flexcomponentbuilder.FlexComponentBuilderDialog",
				"noClass" : null
			}
		},

		FLEXCOMPONENT_DATA_TAB :
		{
			_javaScript 		: [ "FlexComponentDataTab", "alias_js_flexcomponentDataDialog" ],
			_localizedString 	: [ "FlexComponentBuilderDialog", "common.dataTab", "tableBuilder", "summaryTableBuilder" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.flexcomponentbuilder.FlexComponentDataTab" ],
			_publicClasses		:
			{
				"actuate.dialog.FlexComponentDataDialog":"actuate.dialog.impl.flexcomponentbuilder.FlexComponentDataDialog",
				"noClass" : null
			}
		},

		FLEXCROSSTAB_DATA_TAB :
		{
			_javaScript 		: [ "FlexCrosstabDataTab", "alias_js_flexCrosstabDataDialog" ],
			_localizedString 	: [ "FlexComponentBuilderDialog", "common.dataTab", "crosstabBuilderDialog", "crosstabBuilderDialog.dataTab" ],
			_classInstance 		: [	"actuate.dialog.impl.helper.flexcomponentbuilder.FlexCrosstabDataTab" ],
			_cssFiles 			: new Array(
									"crosstabDataTab.css"
									),
			_publicClasses		:
			{
				"actuate.dialog.FlexCrosstabDataDialog":"actuate.dialog.impl.flexcomponentbuilder.FlexCrosstabDataDialog",
				"noClass" : null
			}
		},

		FLEXTABLE_FORMAT_TAB :
		{
			_javaScript 		: [ "FlexTableFormatTab", "alias_js_flexTableFormatDialog" ],
			_localizedString 	: [ "flexComponentBuilderDialog", "tableBuilder", "fontDialog.background",
			                 	    "fontDialog.color", "fontDialog.type", "fontDialog.size",
			                 	    "FlexComponentBuilderDialog.FontOption"],
			_classInstance 		: [	"actuate.dialog.impl.helper.flexcomponentbuilder.FlexTableFormatTab" ],
			_publicClasses		:
			{
				"actuate.dialog.FlexTableFormatDialog":"actuate.dialog.impl.flexcomponentbuilder.FlexTableFormatDialog",
				"noClass" : null
			}
		},

		FLEXCROSSTAB_FORMAT_TAB :
		{
			_javaScript 		: [ "FlexCrosstabFormatTab", "alias_js_flexCrosstabFormatDialog" ],
			_localizedString 	: [ "flexComponentBuilderDialog", "tableBuilder", "fontDialog.background",
			                 	    "fontDialog.color", "fontDialog.type", "fontDialog.size",
				                 	"crosstabBuilderDialog.formatTab", "crosstabBuilderDialog.formatTab.grandTotals",
				                 	"crosstabBuilderDialog.formatTab.subTotals", "flexComponentBuilderDialog.FontOption"],
			_classInstance 		: [	"actuate.dialog.impl.helper.flexcomponentbuilder.FlexCrosstabFormatTab" ],
			_publicClasses		:
			{
				"actuate.dialog.FlexCrosstabFormatDialog":"actuate.dialog.impl.flexcomponentbuilder.FlexCrosstabFormatDialog",
				"noClass" : null
			}
		},

		SINGLEMETRIC_BUILDER_DIALOG :
		{
			_javaScript 		: [ "SingleMetricBuilder", "alias_js_singleMetricBuilderDialog" ],
			_html 				: [ "SingleMetricBuilder" ],
			_localizedString 	: [ "singleMetricBuilder" ],
			_classInstance 		: [ "actuate.dialog.impl.helper.singlemetricbuilder.SingleMetricBuilder", "actuate.dialog.SingleMetricBuilderDialog" ],
  			_entryPoint 		: "actuate.dialog.SingleMetricBuilderDialog",
			_publicClasses		:
			{
				"actuate.dialog.SingleMetricBuilderDialog":"actuate.dialog.impl.singlemetricbuilder.SingleMetricBuilderDialog",
				"noClass" : null
			}
		},

		SINGLEMETRIC_DATA_TAB :
		{
			_javaScript 		: [ "SingleMetricDataTab", "alias_js_singleMetricDataDialog" ],
			_localizedString 	: [ "singleMetricBuilder", "common.dataTab" ],
			_classInstance 		: [ "actuate.dialog.impl.helper.singlemetricbuilder.SingleMetricDataTab" ],
			_publicClasses		:
			{
				"actuate.dialog.SingleMetricDataDialog":"actuate.dialog.impl.singlemetricbuilder.SingleMetricDataDialog",
				"noClass" : null
			}
		},

		SINGLEMETRIC_FORMAT_TAB :
		{
			_javaScript 		: [ "SingleMetricFormatTab", "alias_js_singleMetricFormatDialog" ],
			_localizedString 	: [ "singleMetricBuilder", "formatDialog" ],
			_classInstance 		: [ "actuate.dialog.impl.helper.singlemetricbuilder.SingleMetricFormatTab" ],
			_publicClasses		:
			{
				"actuate.dialog.SingleMetricFormatDialog":"actuate.dialog.impl.singlemetricbuilder.SingleMetricFormatDialog",
				"noClass" : null
			}
		},


		MAP_DATA_TAB :
		{
			_javaScript 		: [ "MapDataTab", "alias_js_mapDataDialog" ],
			_localizedString 	: [ "mapBuilder", "common.dataTab" ],
			_classInstance 		: [ "actuate.dialog.impl.helper.mapbuilder.MapDataTab" ],
			_publicClasses		:
			{
				"actuate.dialog.MapDataDialog":"actuate.dialog.impl.mapbuilder.MapDataDialog",
				"noClass" : null
			}
		},

		MAP_COLLECTION_TAB :
		{
			_javaScript 		: [ "MapCollectionTab", "alias_js_mapCollectionDialog" ],
			_localizedString 	: [ "mapBuilder", "mapCollection" ],
			_classInstance 		: [ "actuate.dialog.impl.helper.mapbuilder.MapCollectionTab" ],
			_publicClasses		:
			{
				"actuate.dialog.MapCollectionDialog":"actuate.dialog.impl.mapbuilder.MapCollectionDialog",
				"noClass" : null
			}
		},
		MAP_FORMAT_TAB :
		{
			_javaScript 		: [ "MapFormatTab", "alias_js_mapFormatDialog" ],
			_localizedString 	: [ "mapBuilder", "mapFormat" ],
			_classInstance 		: [ "actuate.dialog.impl.helper.mapbuilder.MapFormatTab" ],
			_publicClasses		:
			{
				"actuate.dialog.MapFormatDialog":"actuate.dialog.impl.mapbuilder.MapFormatDialog",
				"noClass" : null
			}
		},


		CUSTOMVIZ_BUILDER_DIALOG :
		{
			_javaScript 		: [ "CustomVizBuilder", "alias_js_customVizBuilderDialog" ],
			_html 				: [ "CustomVizBuilder" ],
			_localizedString 	: [ "customVizBuilder" ],
			_classInstance 		: [ "actuate.dialog.impl.helper.customvizbuilder.CustomVizBuilder", "actuate.dialog.CustomVizBuilderDialog" ],
  			_entryPoint 		: "actuate.dialog.CustomVizBuilderDialog",
			_publicClasses		:
			{
				"actuate.dialog.CustomVizBuilderDialog":"actuate.dialog.impl.customvizbuilder.CustomVizBuilderDialog",
				"noClass" : null
			}
		},

		CUSTOMVIZ_DATA_TAB :
		{
			_javaScript 		: [ "CustomVizDataTab", "alias_js_customVizDataDialog" ],
			_localizedString 	: [ "customVizBuilder", "common.dataTab" ],
			_classInstance 		: [ "actuate.dialog.impl.helper.customvizbuilder.CustomVizDataTab" ],
			_publicClasses		:
			{
				"actuate.dialog.CustomVizDataDialog":"actuate.dialog.impl.customvizbuilder.CustomVizDataDialog",
				"noClass" : null
			}
		},

		CUSTOMVIZ_FORMAT_TAB :
		{
			_javaScript 		: [ "CustomVizFormatTab", "alias_js_customVizFormatDialog" ],
			_localizedString 	: [ "customVizBuilder", "formatDialog" ],
			_classInstance 		: [ "actuate.dialog.impl.helper.customvizbuilder.CustomVizFormatTab" ],
			_publicClasses		:
			{
				"actuate.dialog.CustomVizFormatDialog":"actuate.dialog.impl.customvizbuilder.CustomVizFormatDialog",
				"noClass" : null
			}
		}

	}
});
