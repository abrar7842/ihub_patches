// This file is build time generated. Please don't modify. 
actuate.resource.module.define("actuate.builder",
{
_jsPath :  "iv/builder",
_jsFiles : new Array( "builder.js" ),
	_localizedString : false,
	_publicClasses:
	{
		"actuate.builder.Constant"			: "actuate.builder.impl.Constant",
		"actuate.builder.Factory"			: "actuate.builder.impl.Factory",
		"actuate.builder.EventConstants"	: "actuate.builder.impl.EventConstants",
		"noClass" : null
	},
_noComma : null
});
