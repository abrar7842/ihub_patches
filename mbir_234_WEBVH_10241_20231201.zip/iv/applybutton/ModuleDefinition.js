// This file is build time generated. Please don't modify. 
actuate.resource.module.define("actuate.applybutton",
{
_jsPath :  "iv/applybutton",
_jsFiles : new Array( "applybutton.js" ),
	_publicClasses:
	{
		"actuate.applybutton.EventConstants"	: "actuate.applybutton.impl.EventConstants",
		"noClass" : null
	},
_noComma : null
});
