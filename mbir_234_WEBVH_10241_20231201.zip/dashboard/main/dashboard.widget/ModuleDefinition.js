// This file is build time generated. Please don't modify. 
actuate.resource.module.define("actuate.dashboard.widget",
{
_jsPath :  "dashboard/main/dashboard.widget",
_jsFiles : new Array( "dashboard.widget.js" ),
	_publicClasses:
	{
	},	
_noComma : null
});
