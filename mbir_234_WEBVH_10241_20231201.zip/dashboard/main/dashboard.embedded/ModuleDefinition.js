// This file is build time generated. Please don't modify. 
actuate.resource.module.define("actuate.dashboard.embedded",
{
_moduleDependencies : new Array(),
_jsPath :  "dashboard/main/dashboard.embedded",
_jsFiles : new Array( "dashboard.embedded.js" ),
	_publicClasses:
	{
	},	
_noComma : null
});
