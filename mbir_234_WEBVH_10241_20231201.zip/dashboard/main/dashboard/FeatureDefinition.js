/******************************************************************************
 *	Copyright (c) 2004 Actuate Corporation and others.
 *	All rights reserved. This program and the accompanying materials 
 *	are made available under the terms of the Eclipse Public License v1.0
 *	which accompanies this distribution, and is available at
 *		http://www.eclipse.org/legal/epl-v10.html
 *	
 *	@fileoverview This file defines class actuate.iv.constant
 *	@author Actuate Corporation - IV Team
 *	@version 10.0
 *****************************************************************************/
actuate.util.Package.define( "actuate.dashboard" ); 

/**
 * Constant class serves as resource definition class for IV lazy loading use
 * @class This class serves as the resource definition class for IV lazy loading use.
 * @name actuate.iv.FeatureDefinition
 */

actuate.resource.module.feature.define("actuate.dashboard",
{
	
	_localizedStringServlet : "dashboardresource",
	
	/**
	 * Javascript resource definition which can be used by different features.
	 */
	javaScriptAlias : 
{
"GadgetExplorer" : "/feature14640804063472241312.js",
"FolderExplorer" : "/feature13374879898966992422.js",
"NewGadgetBuilderDialog" : "/feature5774649258694899946.js",
"NewSelectorBuilderDialog" : "/feature17859121215012853283.js",
"NewReportLibraryBuilderDialog" : "/feature2418367339896930601.js",
"NewDataManagerDialog" : "/feature6519694570063809034.js"
	}, 
	
	/**
	 * Feature defintions for on demand loading use
	 */
	AVAILABLE_FEATURES : 
	{		
		GADGET_EXPLORER :
		{		 
			/**
			 * JS file list to be loaded
			 * @type {Array}
			 */
			_javaScript : [ 
					"GadgetExplorer" 
					],
			_localizedString : ["gadgetExplorer"]
		},
		
		FOLDER_EXPLORER:
		{
			/**
			 * JS file list to be loaded
			 * @type {Array}
			 */
			_javaScript : [ 
					"FolderExplorer" 
					],
			_localizedString : ["folderExplorer"]
		},
		
		BUILDER_DIALOG:
		{
			/**
			 * JS file list to be loaded
			 * @type {Array}
			 */
			_javaScript : [ 
					"NewGadgetBuilderDialog",
					"NewSelectorBuilderDialog",
					"NewReportLibraryBuilderDialog",
					"NewDataManagerDialog"
					]
		}
	}
});
