// This file is build time generated. Please don't modify. 
actuate.resource.module.define("actuate.dashboard",
{
_jsPath :  "dashboard/main/dashboard",
_jsFiles : new Array( "dashboard.js" ),
_cssPath : "dashboard/css/",
_cssFiles : new Array( "dashboard.css" ),
	_publicClasses:
	{
		"actuate.Dashboard":"actuate.dashboard.Dashboard",
		"noClass":null 
	},
	_localizedStringServlet : "dashboardresource",
    _localizedString : true,
_noComma : null
});
