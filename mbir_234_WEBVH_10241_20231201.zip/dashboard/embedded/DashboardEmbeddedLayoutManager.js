var DashboardEmbeddedLayoutManager = function() {
	gadgets.LayoutManager.call(this);
};
DashboardEmbeddedLayoutManager.inherits(gadgets.LayoutManager);
DashboardEmbeddedLayoutManager.prototype.getGadgetChrome = function(gadget) {
	var chromeId = actuate.util.Constants.GADGET_CHROME_ + gadget.id;
      return chromeId ? document.getElementById(chromeId) : null;
};
