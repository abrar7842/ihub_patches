// This file is build time generated. Please don't modify. 
actuate.resource.module.define("actuate.da",
{
_moduleDependencies : new Array(),
_jsPath :  "da/da",
_jsFiles : new Array( "da.js" ),
_cssPath : "da/styles/",
_cssFiles : new Array( "da.css" ),
	_htmlResourcesUri: "daresource",
	_onLoad : function()
	{
		actuate.xtabanalyzer.impl.bridge.bridge = new actuate.xtabanalyzer.impl.bridge.Bridge( actuate.da.core.daEvent );
		actuate.xtabanalyzer.impl.bridge.bridgeEventDispatcher = new actuate.xtabanalyzer.impl.bridge.BridgeEventDispatcher();
	},
	_onAfterHtmlResourcesLoaded : function( )
	{
		actuate.da.ui.app.daMask =  new actuate.da.ui.app.DAMask( );
		actuate.da.utility.daAggregationUtility = new actuate.da.utility.DAAggregationUtility( );
		actuate.da.data.daData = new actuate.da.data.DAData( );
		actuate.Class.extend( actuate.widget.form.VTypes, {
			positiveInteger : function( val, field )
			{
				return /^[1-9]\d*$/.test( val );
			}
		} );
		var resourcesContainer = document.getElementById(
				actuate.resource.module.getResourcesContainerId(
						this._moduleName
						)
				);
		resourcesContainer.style.display = "inline";
	},
_noComma : null
});
